import { useEffect, useRef } from "react";
import type { EntryRef } from "../domain/types";

type CluePanelProps = {
  title: string;
  entries: EntryRef[];
  cluesByEntryId: Record<string, string>;
  activeEntryId?: string;
  readOnly?: boolean;
  onEntryClick: (entryId: string) => void;
  onClueChange: (entryId: string, text: string) => void;
  onEntryKeyDown: (
    event: React.KeyboardEvent<HTMLTextAreaElement>,
    entryId: string,
  ) => void;
};

function autoSizeTextarea(textarea: HTMLTextAreaElement | null) {
  if (!textarea) {
    return;
  }

  textarea.style.height = "auto";
  textarea.style.height = `${textarea.scrollHeight}px`;
}

export function CluePanel({
  title,
  entries,
  cluesByEntryId,
  activeEntryId,
  readOnly = false,
  onEntryClick,
  onClueChange,
  onEntryKeyDown,
}: CluePanelProps) {
  const activeInputRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    if (!activeInputRef.current) {
      return;
    }

    autoSizeTextarea(activeInputRef.current);

    activeInputRef.current.scrollIntoView({
      block: "center",
      behavior: "smooth",
    });
  }, [activeEntryId]);

  return (
    <section className="clue-panel">
      <h3>{title}</h3>
      <div className="clue-list">
        {entries.map((entry) => {
          const isActive = entry.id === activeEntryId;
          return (
            <div
              key={entry.id}
              className={`clue-row ${isActive ? "active" : ""}`}
              onClick={() => onEntryClick(entry.id)}
            >
              <label>
                <span className="clue-label">{entry.label}</span>
                <textarea
                  ref={(node) => {
                    if (isActive) {
                      activeInputRef.current = node;
                    }
                    autoSizeTextarea(node);
                  }}
                  className="clue-input"
                  rows={1}
                  value={cluesByEntryId[entry.id] ?? ""}
                  disabled={readOnly}
                  onClick={() => onEntryClick(entry.id)}
                  onFocus={(e) => e.currentTarget.select()}
                  onKeyDown={(e) => onEntryKeyDown(e, entry.id)}
                  onChange={(e) => {
                    onClueChange(entry.id, e.target.value);
                    autoSizeTextarea(e.currentTarget);
                  }}
                />
              </label>
            </div>
          );
        })}
      </div>
    </section>
  );
}
