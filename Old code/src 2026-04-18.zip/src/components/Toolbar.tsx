import { forwardRef, useEffect, useRef, useState } from "react";
import type {
  AppMode,
  FormStyle,
  ShapeFamily,
  ShapeVariant,
} from "../domain/types";

type ToolbarProps = {
  size: number;
  allowedSizes: number[];
  mode: AppMode;
  isConstruct: boolean;
  isSolveStrict: boolean;
  isSolveCheckable: boolean;
  hasSolution: boolean;
  wordListEntryCount: number;
  loadedPuzzleFileName: string | null;
  loadedWordListName: string | null;
  lockCompletedWords: boolean;
  randomizeAutofillChoices: boolean;
  isAutofillRunning: boolean;
  autofillStatusText: string;
  shapeFamily: ShapeFamily;
  shapeVariant: ShapeVariant;
  formStyle: FormStyle;
  inverted: boolean;
  canBeSingle: boolean;
  supportsInverted: boolean;
  formTypeTitle: string;
  availableShapeVariants: ShapeVariant[];
  onNewPuzzle: (size: number) => void;
  onSizeChange: (size: number) => void;
  onModeChange: (mode: AppMode) => void;
  onCaptureSolution: () => void;
  onClearGrid: () => void;
  onCheck: () => void;
  onSave: () => void;
  onExportSolverVersion: () => void;
  onLoad: (file: File) => void;
  onLoadWordList: (file: File) => void;
  onFindWords: () => void;
  onAutofill: () => void;
  onStopAutofill: () => void;
  onLockCompletedWordsChange: (value: boolean) => void;
  onRandomizeAutofillChoicesChange: (value: boolean) => void;
  onShapeFamilyChange: (shapeFamily: ShapeFamily) => void;
  onShapeVariantChange: (shapeVariant: ShapeVariant) => void;
  onInvertedChange: (inverted: boolean) => void;
  onFormStyleChange: (formStyle: FormStyle) => void;
};

export const Toolbar = forwardRef<HTMLButtonElement, ToolbarProps>(
  function Toolbar(
    {
      size,
      allowedSizes,
      mode,
      isConstruct,
      isSolveStrict,
      isSolveCheckable,
      hasSolution,
      wordListEntryCount,
      loadedPuzzleFileName,
      loadedWordListName,
      lockCompletedWords,
      randomizeAutofillChoices,
      isAutofillRunning,
      autofillStatusText,
      shapeFamily,
      shapeVariant,
      formStyle,
      inverted,
      canBeSingle,
      supportsInverted,
      formTypeTitle,
      availableShapeVariants,
      onNewPuzzle,
      onSizeChange,
      onModeChange,
      onCaptureSolution,
      onClearGrid,
      onCheck,
      onSave,
      onExportSolverVersion,
      onLoad,
      onLoadWordList,
      onFindWords,
      onAutofill,
      onStopAutofill,
      onLockCompletedWordsChange,
      onRandomizeAutofillChoicesChange,
      onShapeFamilyChange,
      onShapeVariantChange,
      onInvertedChange,
      onFormStyleChange,
    },
    clearButtonRef,
  ) {
    const clearLabel = isConstruct ? "Clear Grid" : "Clear Working Grid";
    const showWordTools = !isSolveStrict;
    const [showAutofillOptions, setShowAutofillOptions] = useState(false);
    const [showFilesSection, setShowFilesSection] = useState(true);
    const [showModeSection, setShowModeSection] = useState(true);
    const [showPuzzleSetupSection, setShowPuzzleSetupSection] = useState(true);
    const [showWordToolsSection, setShowWordToolsSection] =
      useState(!isSolveStrict);
    const [showSolutionSection, setShowSolutionSection] = useState(isConstruct);
    const puzzleFileInputRef = useRef<HTMLInputElement | null>(null);
    const wordListFileInputRef = useRef<HTMLInputElement | null>(null);

    useEffect(() => {
      if (isConstruct) {
        setShowFilesSection(true);
        setShowModeSection(true);
        setShowPuzzleSetupSection(true);
        setShowWordToolsSection(true);
        setShowSolutionSection(false);
        return;
      }

      if (isSolveStrict) {
        setShowFilesSection(false);
        setShowModeSection(true);
        setShowPuzzleSetupSection(false);
        setShowWordToolsSection(false);
        setShowSolutionSection(true);
        return;
      }

      setShowFilesSection(false);
      setShowModeSection(true);
      setShowPuzzleSetupSection(false);
      setShowWordToolsSection(true);
      setShowSolutionSection(true);
    }, [isConstruct, isSolveStrict, isSolveCheckable]);

    return (
      <section className="toolbar-panel">
        <div className="toolbar-section">
          <button
            className="toolbar-section-header"
            type="button"
            onClick={() => setShowFilesSection((prev) => !prev)}
          >
            <span className="toolbar-section-title">Files</span>
            <span>{showFilesSection ? "▾" : "▸"}</span>
          </button>

          {showFilesSection ? (
            <>
              {isConstruct ? (
                <button onClick={() => onNewPuzzle(size)}>New</button>
              ) : null}

              <input
                ref={puzzleFileInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden-file-input"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    onLoad(file);
                    e.target.value = "";
                  }
                }}
              />

              <button
                type="button"
                onClick={() => puzzleFileInputRef.current?.click()}
              >
                Load Puzzle
              </button>

              <div className="toolbar-status">
                Puzzle file: {loadedPuzzleFileName ?? "none loaded"}
              </div>

              {isConstruct ? <button onClick={onSave}>Save</button> : null}

              {isConstruct ? (
                <button onClick={onExportSolverVersion} disabled={!hasSolution}>
                  Export Solver Version
                </button>
              ) : null}

              {showWordTools ? (
                <>
                  <input
                    ref={wordListFileInputRef}
                    type="file"
                    accept=".txt,text/plain"
                    className="hidden-file-input"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        onLoadWordList(file);
                        e.target.value = "";
                      }
                    }}
                  />

                  <button
                    type="button"
                    onClick={() => wordListFileInputRef.current?.click()}
                  >
                    Load Word List
                  </button>

                  <div className="toolbar-status">
                    Word list:{" "}
                    {loadedWordListName
                      ? `${loadedWordListName} (${wordListEntryCount.toLocaleString()} eligible entries)`
                      : "none loaded"}
                  </div>
                </>
              ) : null}
            </>
          ) : null}
        </div>

        <div className="toolbar-section">
          <button
            className="toolbar-section-header"
            type="button"
            onClick={() => setShowModeSection((prev) => !prev)}
          >
            <span className="toolbar-section-title">
              {isConstruct
                ? "Constructor Mode"
                : isSolveStrict
                  ? "Solve Mode (Strict)"
                  : "Solve Mode (Checkable)"}
            </span>
            <span>{showModeSection ? "▾" : "▸"}</span>
          </button>

          {showModeSection ? (
            <fieldset className="mode-fieldset">
              <legend>Mode</legend>

              <label className="radio-option">
                <input
                  type="radio"
                  name="mode"
                  checked={mode === "construct"}
                  onChange={() => onModeChange("construct")}
                />
                <span>Construct</span>
              </label>

              <label className="radio-option">
                <input
                  type="radio"
                  name="mode"
                  checked={mode === "solve_strict"}
                  onChange={() => onModeChange("solve_strict")}
                />
                <span>Solve (Strict)</span>
              </label>

              <label className="radio-option">
                <input
                  type="radio"
                  name="mode"
                  checked={mode === "solve_checkable"}
                  onChange={() => onModeChange("solve_checkable")}
                />
                <span>Solve (Checkable)</span>
              </label>
            </fieldset>
          ) : null}
        </div>

        {isConstruct ? (
          <div className="toolbar-section">
            <button
              className="toolbar-section-header"
              type="button"
              onClick={() => setShowPuzzleSetupSection((prev) => !prev)}
            >
              <span className="toolbar-section-title">Puzzle Setup</span>
              <span>{showPuzzleSetupSection ? "▾" : "▸"}</span>
            </button>

            {showPuzzleSetupSection ? (
              <>
                <label>
                  Shape
                  <select
                    value={shapeFamily}
                    onChange={(e) =>
                      onShapeFamilyChange(e.target.value as ShapeFamily)
                    }
                  >
                    <option value="square">Square</option>
                    <option value="windmill">Windmill</option>
                    <option value="halfsquare">Half-square</option>
                  </select>
                </label>

                {availableShapeVariants.length > 1 ? (
                  <label>
                    Variant
                    <select
                      value={shapeVariant}
                      onChange={(e) =>
                        onShapeVariantChange(e.target.value as ShapeVariant)
                      }
                    >
                      {availableShapeVariants.map((variant) => (
                        <option key={variant} value={variant}>
                          {variant === "standard"
                            ? "Standard"
                            : variant.charAt(0).toUpperCase() +
                              variant.slice(1)}
                        </option>
                      ))}
                    </select>
                  </label>
                ) : null}

                {supportsInverted ? (
                  <label className="checkbox-option">
                    <input
                      type="checkbox"
                      checked={inverted}
                      onChange={(e) => onInvertedChange(e.target.checked)}
                    />
                    <span>Inverted</span>
                  </label>
                ) : null}

                <label>
                  Size
                  <select
                    value={size}
                    onChange={(e) => onSizeChange(Number(e.target.value))}
                  >
                    {allowedSizes.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  Form Style
                  <select
                    value={formStyle}
                    onChange={(e) =>
                      onFormStyleChange(e.target.value as FormStyle)
                    }
                  >
                    <option value="double">Double</option>
                    <option value="single" disabled={!canBeSingle}>
                      Single
                    </option>
                  </select>
                </label>
              </>
            ) : null}
          </div>
        ) : null}

        {showWordTools ? (
          <div className="toolbar-section">
            <button
              className="toolbar-section-header"
              type="button"
              onClick={() => setShowWordToolsSection((prev) => !prev)}
            >
              <span className="toolbar-section-title">Word Tools</span>
              <span>{showWordToolsSection ? "▾" : "▸"}</span>
            </button>

            {showWordToolsSection ? (
              <>
                <button onClick={onFindWords}>Find Words</button>

                <button onClick={onAutofill} disabled={isAutofillRunning}>
                  Autofill
                </button>

                {isAutofillRunning ? (
                  <button onClick={onStopAutofill}>Stop Autofill</button>
                ) : null}

                <button
                  className="toolbar-toggle"
                  onClick={() => setShowAutofillOptions((prev) => !prev)}
                  type="button"
                >
                  {showAutofillOptions
                    ? "Hide Autofill Options"
                    : "Show Autofill Options"}
                </button>

                {showAutofillOptions ? (
                  <div className="toolbar-subsection">
                    <label className="checkbox-option">
                      <input
                        type="checkbox"
                        checked={lockCompletedWords}
                        onChange={(e) =>
                          onLockCompletedWordsChange(e.target.checked)
                        }
                      />
                      <span>Lock completed words during autofill</span>
                    </label>

                    <label className="checkbox-option">
                      <input
                        type="checkbox"
                        checked={randomizeAutofillChoices}
                        onChange={(e) =>
                          onRandomizeAutofillChoicesChange(e.target.checked)
                        }
                      />
                      <span>Randomize autofill choices</span>
                    </label>
                  </div>
                ) : null}
              </>
            ) : null}
          </div>
        ) : null}

        <div className="toolbar-section">
          <button
            className="toolbar-section-header"
            type="button"
            onClick={() => setShowSolutionSection((prev) => !prev)}
          >
            <span className="toolbar-section-title">
              {isConstruct ? "Solution" : "Solve"}
            </span>
            <span>{showSolutionSection ? "▾" : "▸"}</span>
          </button>

          {showSolutionSection ? (
            <>
              {isConstruct ? (
                <button onClick={onCaptureSolution} disabled={!isConstruct}>
                  Capture Solution
                </button>
              ) : null}

              <button ref={clearButtonRef} onClick={onClearGrid}>
                {clearLabel}
              </button>

              {isSolveCheckable ? (
                <button onClick={onCheck} disabled={!hasSolution}>
                  Check
                </button>
              ) : null}
            </>
          ) : null}
        </div>
      </section>
    );
  },
);
