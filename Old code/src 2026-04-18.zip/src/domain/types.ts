export type ShapeFamily = "square" | "windmill" | "halfsquare";
export type ShapeVariant = "standard" | "left" | "right";
export type EntryDirection = "across" | "down";
export type AppMode = "construct" | "solve_strict" | "solve_checkable";
export type FormStyle = "double" | "single";

export interface PuzzleSpec {
  shapeFamily: ShapeFamily;
  size: number;
  shapeVariant?: ShapeVariant;
  formStyle?: FormStyle;
  inverted?: boolean;
}

export interface Cell {
  id: string;
  row: number;
  col: number;
}

export interface EntryRef {
  id: string;
  number: number;
  label: string;
  direction: EntryDirection;
  cells: string[];
}

export interface Topology {
  cells: Cell[];
  entries: EntryRef[];
}

export interface Clue {
  formWordId: string;
  text: string;
}

export interface PuzzleMetadata {
  title: string;
  author: string;
}

export interface PuzzleContent {
  metadata: PuzzleMetadata;
  clues: Clue[];
}

export interface FormFillState {
  fillsByFormWordId: Record<string, string>;
}

export interface PuzzleState extends FormFillState {}

export interface SolutionState extends FormFillState {}

export interface SavedPuzzle {
  version: 1;
  spec: PuzzleSpec;
  topology: Topology;
  content: PuzzleContent;
  state: PuzzleState;
  solution?: SolutionState;
}

export interface SelectionState {
  cellId: string | null;
  direction: EntryDirection;
}
