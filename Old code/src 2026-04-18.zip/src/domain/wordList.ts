import type { EntryRef } from "./types";

export interface LoadedWordList {
  name: string;
  allEntries: string[];
  eligibleEntries: string[];
  byLength: Map<number, string[]>;
}

export interface WordListMatchResult {
  total: number;
  matches: string[];
}

const LETTERS_ONLY_RE = /^\p{L}+$/u;

function normalizeWordListEntry(value: string): string {
  return value.normalize("NFC").trim().toLocaleUpperCase();
}

function isEligibleGridEntry(value: string): boolean {
  return LETTERS_ONLY_RE.test(value);
}

export function parseWordListText(
  text: string,
  name = "wordlist",
): LoadedWordList {
  const seen = new Set<string>();
  const allEntries: string[] = [];
  const eligibleEntries: string[] = [];
  const byLength = new Map<number, string[]>();

  const lines = text.split(/\r?\n/);

  for (const line of lines) {
    const normalized = normalizeWordListEntry(line);
    if (!normalized) {
      continue;
    }

    if (seen.has(normalized)) {
      continue;
    }
    seen.add(normalized);

    allEntries.push(normalized);

    if (!isEligibleGridEntry(normalized)) {
      continue;
    }

    eligibleEntries.push(normalized);

    const bucket = byLength.get(normalized.length);
    if (bucket) {
      bucket.push(normalized);
    } else {
      byLength.set(normalized.length, [normalized]);
    }
  }

  return {
    name,
    allEntries,
    eligibleEntries,
    byLength,
  };
}

export function findMatchingWords(
  wordList: LoadedWordList,
  pattern: string,
  offset = 0,
  limit = 100,
): WordListMatchResult {
  const normalizedPattern = pattern.normalize("NFC").toLocaleUpperCase();
  const candidates = wordList.byLength.get(normalizedPattern.length) ?? [];

  const allMatches = candidates.filter((entry) =>
    entryMatchesPattern(entry, normalizedPattern),
  );

  return {
    total: allMatches.length,
    matches: allMatches.slice(offset, offset + limit),
  };
}

export function getPatternForEntry(
  entry: EntryRef | undefined,
  fillsByCellId: Record<string, string>,
): string {
  if (!entry) {
    return "";
  }

  return entry.cells
    .map((cellId) => {
      const value = (fillsByCellId[cellId] ?? "").normalize("NFC");
      return value === "" ? "_" : value.toLocaleUpperCase();
    })
    .join("");
}

function entryMatchesPattern(entry: string, pattern: string): boolean {
  if (entry.length !== pattern.length) {
    return false;
  }

  for (let i = 0; i < pattern.length; i += 1) {
    const patternChar = pattern[i];
    if (patternChar === "_") {
      continue;
    }

    if (entry[i] !== patternChar) {
      return false;
    }
  }

  return true;
}
