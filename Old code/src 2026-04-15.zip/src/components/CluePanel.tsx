import { useEffect, useRef } from "react";
import type { EntryRef } from "../domain/types";

type CluePanelProps = {
  title: string;
  entries: EntryRef[];
  cluesByEntryId: Record<string, string>;
  activeEntryId?: string;
  readOnly?: boolean;
  onEntryClick: (entryId: string) => void;
  onClueChange: (entryId: string, text: string) => void;
  onEntryKeyDown: (
    event: React.KeyboardEvent<HTMLInputElement>,
    entryId: string,
  ) => void;
};

export function CluePanel({
  title,
  entries,
  cluesByEntryId,
  activeEntryId,
  readOnly = false,
  onEntryClick,
  onClueChange,
  onEntryKeyDown,
}: CluePanelProps) {
  const activeInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    activeInputRef.current?.scrollIntoView({
      block: "nearest",
      behavior: "smooth",
    });
  }, [activeEntryId]);

  return (
    <section className="clue-panel">
      <h3>{title}</h3>
      <div className="clue-list">
        {entries.map((entry) => {
          const isActive = entry.id === activeEntryId;
          return (
            <div
              key={entry.id}
              className={`clue-row ${isActive ? "active" : ""}`}
              onClick={() => onEntryClick(entry.id)}
            >
              <label>
                <span className="clue-label">{entry.label}</span>
                <input
                  ref={isActive ? activeInputRef : null}
                  type="text"
                  value={cluesByEntryId[entry.id] ?? ""}
                  disabled={readOnly}
                  onClick={() => onEntryClick(entry.id)}
                  onKeyDown={(e) => onEntryKeyDown(e, entry.id)}
                  onChange={(e) => onClueChange(entry.id, e.target.value)}
                />
              </label>
            </div>
          );
        })}
      </div>
    </section>
  );
}
