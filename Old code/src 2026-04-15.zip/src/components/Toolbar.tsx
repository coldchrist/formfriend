import { forwardRef, useRef, useState } from "react";
import type { AppMode, ShapeFamily, ShapeVariant } from "../domain/types";

type ToolbarProps = {
  size: number;
  mode: AppMode;
  hasSolution: boolean;
  wordListEntryCount: number;
  loadedPuzzleFileName: string | null;
  loadedWordListName: string | null;
  lockCompletedWords: boolean;
  randomizeAutofillChoices: boolean;
  isAutofillRunning: boolean;
  autofillStatusText: string;
  uiStatusText: string;
  uiStatusKind: "info" | "success" | "error";
  shapeFamily: ShapeFamily;
  shapeVariant: ShapeVariant;
  availableShapeVariants: ShapeVariant[];
  onNewPuzzle: (size: number) => void;
  onSizeChange: (size: number) => void;
  onModeChange: (mode: AppMode) => void;
  onCaptureSolution: () => void;
  onClearGrid: () => void;
  onCheck: () => void;
  onSave: () => void;
  onExportSolverVersion: () => void;
  onLoad: (file: File) => void;
  onLoadWordList: (file: File) => void;
  onFindWords: () => void;
  onAutofill: () => void;
  onStopAutofill: () => void;
  onLockCompletedWordsChange: (value: boolean) => void;
  onRandomizeAutofillChoicesChange: (value: boolean) => void;
  onShapeFamilyChange: (shapeFamily: ShapeFamily) => void;
  onShapeVariantChange: (shapeVariant: ShapeVariant) => void;
};

export const Toolbar = forwardRef<HTMLButtonElement, ToolbarProps>(
  function Toolbar(
    {
      size,
      mode,
      hasSolution,
      wordListEntryCount,
      loadedPuzzleFileName,
      loadedWordListName,
      lockCompletedWords,
      randomizeAutofillChoices,
      isAutofillRunning,
      autofillStatusText,
      uiStatusText,
      uiStatusKind,
      shapeFamily,
      shapeVariant,
      availableShapeVariants,
      onNewPuzzle,
      onSizeChange,
      onModeChange,
      onCaptureSolution,
      onClearGrid,
      onCheck,
      onSave,
      onExportSolverVersion,
      onLoad,
      onLoadWordList,
      onFindWords,
      onAutofill,
      onStopAutofill,
      onLockCompletedWordsChange,
      onRandomizeAutofillChoicesChange,
      onShapeFamilyChange,
      onShapeVariantChange,
    },
    clearButtonRef,
  ) {
    const isConstruct = mode === "construct";
    const clearLabel = isConstruct ? "Clear Grid" : "Clear Working Grid";
    const [showAutofillOptions, setShowAutofillOptions] = useState(false);
    const puzzleFileInputRef = useRef<HTMLInputElement | null>(null);
    const wordListFileInputRef = useRef<HTMLInputElement | null>(null);

    return (
      <section className="toolbar-panel">
        <div className="toolbar-section">
          <div className="toolbar-section-title">Files</div>

          <button onClick={() => onNewPuzzle(size)}>New</button>

          <input
            ref={puzzleFileInputRef}
            type="file"
            accept=".json,application/json"
            className="hidden-file-input"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onLoad(file);
                e.target.value = "";
              }
            }}
          />

          <button
            type="button"
            onClick={() => puzzleFileInputRef.current?.click()}
          >
            Load Puzzle
          </button>

          <div className="toolbar-status">
            Puzzle file: {loadedPuzzleFileName ?? "none loaded"}
          </div>

          <button onClick={onSave}>Save</button>

          <button onClick={onExportSolverVersion} disabled={!hasSolution}>
            Export Solver Version
          </button>

          <input
            ref={wordListFileInputRef}
            type="file"
            accept=".txt,text/plain"
            className="hidden-file-input"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onLoadWordList(file);
                e.target.value = "";
              }
            }}
          />

          <button
            type="button"
            onClick={() => wordListFileInputRef.current?.click()}
          >
            Load Word List
          </button>

          <div className="toolbar-status">
            Word list:{" "}
            {loadedWordListName
              ? `${loadedWordListName} (${wordListEntryCount.toLocaleString()} eligible entries)`
              : "none loaded"}
          </div>
        </div>

        <div className="toolbar-section">
          <div className="toolbar-section-title">Puzzle</div>

          <label>
            Shape
            <select
              value={shapeFamily}
              onChange={(e) =>
                onShapeFamilyChange(e.target.value as ShapeFamily)
              }
            >
              <option value="square">Square</option>
              <option value="windmill">Windmill</option>
            </select>
          </label>

          {availableShapeVariants.length > 1 ? (
            <label>
              Variant
              <select
                value={shapeVariant}
                onChange={(e) =>
                  onShapeVariantChange(e.target.value as ShapeVariant)
                }
              >
                {availableShapeVariants.map((variant) => (
                  <option key={variant} value={variant}>
                    {variant === "standard"
                      ? "Standard"
                      : variant.charAt(0).toUpperCase() + variant.slice(1)}
                  </option>
                ))}
              </select>
            </label>
          ) : null}

          <label>
            Size
            <select
              value={size}
              onChange={(e) => onSizeChange(Number(e.target.value))}
            >
              {[3, 4, 5, 6, 7, 8, 9].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </label>

          <fieldset className="mode-fieldset">
            <legend>Mode</legend>

            <label className="radio-option">
              <input
                type="radio"
                name="mode"
                checked={mode === "construct"}
                onChange={() => onModeChange("construct")}
              />
              <span>Construct</span>
            </label>

            <label className="radio-option">
              <input
                type="radio"
                name="mode"
                checked={mode === "solve"}
                onChange={() => onModeChange("solve")}
              />
              <span>Solve</span>
            </label>
          </fieldset>
        </div>

        <div className="toolbar-section">
          <div className="toolbar-section-title">Word Tools</div>

          <button onClick={onFindWords}>Find Words</button>

          <button onClick={onAutofill} disabled={isAutofillRunning}>
            Autofill
          </button>

          {isAutofillRunning ? (
            <button onClick={onStopAutofill}>Stop Autofill</button>
          ) : null}

          <div className="toolbar-status">{autofillStatusText}</div>

          <button
            className="toolbar-toggle"
            onClick={() => setShowAutofillOptions((prev) => !prev)}
            type="button"
          >
            {showAutofillOptions
              ? "Hide Autofill Options"
              : "Show Autofill Options"}
          </button>

          {showAutofillOptions ? (
            <div className="toolbar-subsection">
              <label className="checkbox-option">
                <input
                  type="checkbox"
                  checked={lockCompletedWords}
                  onChange={(e) => onLockCompletedWordsChange(e.target.checked)}
                />
                <span>Lock completed words during autofill</span>
              </label>

              <label className="checkbox-option">
                <input
                  type="checkbox"
                  checked={randomizeAutofillChoices}
                  onChange={(e) =>
                    onRandomizeAutofillChoicesChange(e.target.checked)
                  }
                />
                <span>Randomize autofill choices</span>
              </label>
            </div>
          ) : null}
        </div>

        <div className="toolbar-section">
          <div className="toolbar-section-title">Solution</div>

          <button onClick={onCaptureSolution} disabled={!isConstruct}>
            Capture Solution
          </button>

          <button ref={clearButtonRef} onClick={onClearGrid}>
            {clearLabel}
          </button>

          <button onClick={onCheck} disabled={!hasSolution}>
            Check
          </button>
        </div>
        <div className="toolbar-section">
          <div className="toolbar-section-title">Status</div>
          <div
            className={`toolbar-status-message toolbar-status-${uiStatusKind}`}
          >
            {uiStatusText}
          </div>
        </div>
      </section>
    );
  },
);
