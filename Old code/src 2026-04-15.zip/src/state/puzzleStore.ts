import { buildEmptyContent, buildTopology } from "../domain/squareTopology";
import {
  buildEmptyFormFillState,
  buildFormModelFromTopology,
} from "../domain/formModel";

import type {
  AppMode,
  EntryDirection,
  PuzzleContent,
  PuzzleSpec,
  PuzzleState,
  SelectionState,
  SolutionState,
  Topology,
  ShapeFamily,
  ShapeVariant,
} from "../domain/types";

export interface PuzzleStoreState {
  mode: AppMode;
  spec: PuzzleSpec;
  topology: Topology;
  content: PuzzleContent;
  state: PuzzleState;
  solution?: SolutionState;
  selection: SelectionState;
}

export function createInitialPuzzleStore(
  size = 5,
  shapeFamily: ShapeFamily = "square",
  shapeVariant: ShapeVariant = "standard",
): PuzzleStoreState {
  const spec: PuzzleSpec =
    shapeFamily === "windmill"
      ? {
          shapeFamily,
          size,
          shapeVariant: shapeVariant === "standard" ? "left" : shapeVariant,
        }
      : {
          shapeFamily,
          size,
          shapeVariant: "standard",
        };

  const topology = buildTopology(spec);

  return {
    mode: "construct",
    spec,
    topology,
    content: buildEmptyContent(topology),
    state: buildEmptyFormFillState(buildFormModelFromTopology(topology)),
    solution: undefined,
    selection: {
      cellId: topology.cells[0]?.id ?? null,
      direction: "across",
    },
  };
}

export function getEntryForCell(
  topology: Topology,
  cellId: string,
  direction: EntryDirection,
) {
  return topology.entries.find(
    (entry) => entry.direction === direction && entry.cells.includes(cellId),
  );
}

export function toggleDirectionForRepeatedCellClick(
  topology: Topology,
  selection: SelectionState,
  clickedCellId: string,
): SelectionState {
  if (selection.cellId !== clickedCellId) {
    return {
      cellId: clickedCellId,
      direction: "across",
    };
  }

  const nextDirection: EntryDirection =
    selection.direction === "across" ? "down" : "across";

  const nextEntry = getEntryForCell(topology, clickedCellId, nextDirection);
  if (!nextEntry) {
    return selection;
  }

  return {
    cellId: clickedCellId,
    direction: nextDirection,
  };
}
