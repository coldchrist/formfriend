import {
  findMatchingWords,
  getPatternForEntry,
  type LoadedWordList,
} from "./wordList";
import type { EntryRef, Topology } from "./types";

export type AutofillOptions = {
  lockCompletedWords: boolean;
  randomizeChoices: boolean;
};

export type AutofillProgress = {
  nodesVisited: number;
};

export type AutofillRuntime = {
  shouldContinue: () => boolean;
  onProgress?: (progress: AutofillProgress) => void;
  progressInterval?: number;
  yieldInterval?: number;
  random?: () => number;
};

type AutofillSearchState = {
  fillsByCellId: Record<string, string>;
  usedWords: Set<string>;
};

type AutofillInternalState = {
  nodesVisited: number;
};

function applyWordToEntry(
  fillsByCellId: Record<string, string>,
  entry: EntryRef,
  word: string,
): Record<string, string> {
  const updated = { ...fillsByCellId };

  for (let i = 0; i < entry.cells.length; i += 1) {
    updated[entry.cells[i]] = word[i] ?? "";
  }

  return updated;
}

function isEntryComplete(
  entry: EntryRef,
  fillsByCellId: Record<string, string>,
): boolean {
  return entry.cells.every((cellId) => (fillsByCellId[cellId] ?? "") !== "");
}

function getCompletedEntryWord(
  entry: EntryRef,
  fillsByCellId: Record<string, string>,
): string | null {
  if (!isEntryComplete(entry, fillsByCellId)) {
    return null;
  }

  return entry.cells.map((cellId) => fillsByCellId[cellId] ?? "").join("");
}

function shuffleWords(words: string[], random: () => number): string[] {
  const shuffled = [...words];

  for (let i = shuffled.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  return shuffled;
}

function getCandidatesForEntry(
  wordList: LoadedWordList,
  entry: EntryRef,
  fillsByCellId: Record<string, string>,
  usedWords: Set<string>,
  options: AutofillOptions,
  runtime: AutofillRuntime,
): string[] {
  const pattern = getPatternForEntry(entry, fillsByCellId);

  const matches = findMatchingWords(
    wordList,
    pattern,
    0,
    Number.MAX_SAFE_INTEGER,
  ).matches.filter((word) => !usedWords.has(word));

  if (!options.randomizeChoices) {
    return matches;
  }

  return shuffleWords(matches, runtime.random ?? Math.random);
}

function chooseNextEntry(
  topology: Topology,
  fillsByCellId: Record<string, string>,
  wordList: LoadedWordList,
  usedWords: Set<string>,
  options: AutofillOptions,
  runtime: AutofillRuntime,
): { entry: EntryRef; candidates: string[] } | null {
  let bestEntry: EntryRef | null = null;
  let bestCandidates: string[] | null = null;

  for (const entry of topology.entries) {
    const entryIsComplete = isEntryComplete(entry, fillsByCellId);

    if (options.lockCompletedWords && entryIsComplete) {
      continue;
    }

    const candidates = getCandidatesForEntry(
      wordList,
      entry,
      fillsByCellId,
      usedWords,
      options,
      runtime,
    );

    if (candidates.length === 0) {
      return { entry, candidates };
    }

    if (
      !bestEntry ||
      !bestCandidates ||
      candidates.length < bestCandidates.length
    ) {
      bestEntry = entry;
      bestCandidates = candidates;

      if (candidates.length === 1) {
        break;
      }
    }
  }

  if (!bestEntry || !bestCandidates) {
    return null;
  }

  return {
    entry: bestEntry,
    candidates: bestCandidates,
  };
}

async function maybeYield(
  runtime: AutofillRuntime,
  internal: AutofillInternalState,
): Promise<boolean> {
  const yieldInterval = runtime.yieldInterval ?? 250;

  if (internal.nodesVisited % yieldInterval !== 0) {
    return runtime.shouldContinue();
  }

  await new Promise<void>((resolve) => {
    setTimeout(resolve, 0);
  });

  return runtime.shouldContinue();
}

async function recursivelyAutofill(
  topology: Topology,
  wordList: LoadedWordList,
  state: AutofillSearchState,
  options: AutofillOptions,
  runtime: AutofillRuntime,
  internal: AutofillInternalState,
): Promise<Record<string, string> | null> {
  if (!runtime.shouldContinue()) {
    return null;
  }

  internal.nodesVisited += 1;

  const progressInterval = runtime.progressInterval ?? 1000;
  if (
    runtime.onProgress &&
    (internal.nodesVisited === 1 ||
      internal.nodesVisited % progressInterval === 0)
  ) {
    runtime.onProgress({
      nodesVisited: internal.nodesVisited,
    });
  }

  if (!(await maybeYield(runtime, internal))) {
    return null;
  }

  const next = chooseNextEntry(
    topology,
    state.fillsByCellId,
    wordList,
    state.usedWords,
    options,
    runtime,
  );

  if (next === null) {
    return state.fillsByCellId;
  }

  if (next.candidates.length === 0) {
    return null;
  }

  for (const candidate of next.candidates) {
    if (!runtime.shouldContinue()) {
      return null;
    }

    const updatedFills = applyWordToEntry(
      state.fillsByCellId,
      next.entry,
      candidate,
    );

    const nextUsedWords = new Set(state.usedWords);
    nextUsedWords.add(candidate);

    const result = await recursivelyAutofill(
      topology,
      wordList,
      {
        fillsByCellId: updatedFills,
        usedWords: nextUsedWords,
      },
      options,
      runtime,
      internal,
    );

    if (result) {
      return result;
    }
  }

  return null;
}

function collectInitiallyUsedWords(
  topology: Topology,
  fillsByCellId: Record<string, string>,
): Set<string> {
  const usedWords = new Set<string>();

  for (const entry of topology.entries) {
    const word = getCompletedEntryWord(entry, fillsByCellId);
    if (word) {
      usedWords.add(word);
    }
  }

  return usedWords;
}

export async function autofillGrid(
  topology: Topology,
  fillsByCellId: Record<string, string>,
  wordList: LoadedWordList,
  options: AutofillOptions,
  runtime: AutofillRuntime,
): Promise<Record<string, string> | null> {
  const internal: AutofillInternalState = {
    nodesVisited: 0,
  };

  const result = await recursivelyAutofill(
    topology,
    wordList,
    {
      fillsByCellId: { ...fillsByCellId },
      usedWords: collectInitiallyUsedWords(topology, fillsByCellId),
    },
    options,
    runtime,
    internal,
  );

  if (runtime.onProgress) {
    runtime.onProgress({
      nodesVisited: internal.nodesVisited,
    });
  }

  return result;
}
