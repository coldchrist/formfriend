import type { EntryDirection, FormFillState, Topology } from "./types";

export interface VisibleCell {
  id: string;
  row: number;
  col: number;
}

export interface FormWord {
  id: string;
  length: number;
  label?: string;
}

export interface DisplayEntry {
  id: string;
  number: number;
  label: string;
  direction: EntryDirection;
  cellIds: string[];
  formWordId: string;
}

export interface CellFormWordMapping {
  cellId: string;
  formWordId: string;
  formWordOffset: number;
  displayEntryId?: string;
}

export interface FormModel {
  visibleCells: VisibleCell[];
  formWords: FormWord[];
  displayEntries: DisplayEntry[];
  mappings: CellFormWordMapping[];
}

export function buildFormModelFromTopology(topology: Topology): FormModel {
  const visibleCells: VisibleCell[] = topology.cells.map((cell) => ({
    id: cell.id,
    row: cell.row,
    col: cell.col,
  }));

  const formWords: FormWord[] = [];
  const displayEntries: DisplayEntry[] = [];
  const mappings: CellFormWordMapping[] = [];

  for (const entry of topology.entries) {
    const formWordId = `FW_${entry.id}`;

    formWords.push({
      id: formWordId,
      length: entry.cells.length,
      label: entry.label,
    });

    displayEntries.push({
      id: entry.id,
      number: entry.number,
      label: entry.label,
      direction: entry.direction,
      cellIds: [...entry.cells],
      formWordId,
    });

    for (let i = 0; i < entry.cells.length; i += 1) {
      mappings.push({
        cellId: entry.cells[i],
        formWordId,
        formWordOffset: i,
        displayEntryId: entry.id,
      });
    }
  }

  return {
    visibleCells,
    formWords,
    displayEntries,
    mappings,
  };
}

export function buildEmptyFormFillState(formModel: FormModel): FormFillState {
  const fillsByFormWordId: Record<string, string> = {};

  for (const formWord of formModel.formWords) {
    fillsByFormWordId[formWord.id] = "";
  }

  return {
    fillsByFormWordId,
  };
}

export function getMappingsForCell(
  formModel: FormModel,
  cellId: string,
): CellFormWordMapping[] {
  return formModel.mappings.filter((mapping) => mapping.cellId === cellId);
}

export function getMappingsForFormWord(
  formModel: FormModel,
  formWordId: string,
): CellFormWordMapping[] {
  return formModel.mappings.filter(
    (mapping) => mapping.formWordId === formWordId,
  );
}

export function getDisplayEntryById(
  formModel: FormModel,
  displayEntryId: string,
): DisplayEntry | undefined {
  return formModel.displayEntries.find((entry) => entry.id === displayEntryId);
}

export function getFormWordById(
  formModel: FormModel,
  formWordId: string,
): FormWord | undefined {
  return formModel.formWords.find((formWord) => formWord.id === formWordId);
}

export function getDisplayedCellValue(
  formModel: FormModel,
  fillState: FormFillState,
  cellId: string,
): string {
  const mappings = getMappingsForCell(formModel, cellId);

  let resolved = "";

  for (const mapping of mappings) {
    const fill = fillState.fillsByFormWordId[mapping.formWordId] ?? "";
    const value = fill[mapping.formWordOffset] ?? "";

    if (!value) {
      continue;
    }

    if (!resolved) {
      resolved = value;
      continue;
    }

    if (resolved !== value) {
      return "?";
    }
  }

  return resolved || "";
}

export function getDisplayEntryPattern(
  formModel: FormModel,
  fillState: FormFillState,
  displayEntry: DisplayEntry,
): string {
  return displayEntry.cellIds
    .map((cellId) => {
      const value = getDisplayedCellValue(formModel, fillState, cellId);
      return value || "_";
    })
    .join("");
}

export function buildFormFillStateFromCellFills(
  formModel: FormModel,
  fillsByCellId: Record<string, string>,
): FormFillState {
  const fillsByFormWordId: Record<string, string> = {};

  for (const formWord of formModel.formWords) {
    fillsByFormWordId[formWord.id] = "_".repeat(formWord.length);
  }

  for (const formWord of formModel.formWords) {
    const mappings = getMappingsForFormWord(formModel, formWord.id).sort(
      (a, b) => a.formWordOffset - b.formWordOffset,
    );

    const chars = new Array(formWord.length).fill("_");

    for (const mapping of mappings) {
      const value = fillsByCellId[mapping.cellId] ?? "";
      if (value) {
        chars[mapping.formWordOffset] = value;
      }
    }

    fillsByFormWordId[formWord.id] = chars.join("");
  }

  return {
    fillsByFormWordId,
  };
}

export function buildCellFillsFromFormFillState(
  formModel: FormModel,
  fillState: FormFillState,
): Record<string, string> {
  const fillsByCellId: Record<string, string> = {};

  for (const cell of formModel.visibleCells) {
    const value = getDisplayedCellValue(formModel, fillState, cell.id);
    fillsByCellId[cell.id] = value === "_" || value === "?" ? "" : value;
  }

  return fillsByCellId;
}

export function cellFillsEqual(
  left: Record<string, string>,
  right: Record<string, string>,
): boolean {
  const keys = new Set([...Object.keys(left), ...Object.keys(right)]);

  for (const key of keys) {
    if ((left[key] ?? "") !== (right[key] ?? "")) {
      return false;
    }
  }

  return true;
}

export function getRoundTripCellFills(
  formModel: FormModel,
  fillsByCellId: Record<string, string>,
): Record<string, string> {
  const formFillState = buildFormFillStateFromCellFills(
    formModel,
    fillsByCellId,
  );

  return buildCellFillsFromFormFillState(formModel, formFillState);
}

export function formModelRoundTripMatchesCellFills(
  formModel: FormModel,
  fillsByCellId: Record<string, string>,
): boolean {
  const roundTrip = getRoundTripCellFills(formModel, fillsByCellId);
  return cellFillsEqual(fillsByCellId, roundTrip);
}

export function getDisplayEntryPatternById(
  formModel: FormModel,
  fillState: FormFillState,
  displayEntryId: string,
): string {
  const displayEntry = getDisplayEntryById(formModel, displayEntryId);
  if (!displayEntry) {
    return "";
  }

  return getDisplayEntryPattern(formModel, fillState, displayEntry);
}

export function applyWordToDisplayEntry(
  formModel: FormModel,
  fillState: FormFillState,
  displayEntryId: string,
  word: string,
): FormFillState {
  const displayEntry = getDisplayEntryById(formModel, displayEntryId);
  if (!displayEntry) {
    return fillState;
  }

  return {
    fillsByFormWordId: {
      ...fillState.fillsByFormWordId,
      [displayEntry.formWordId]: word,
    },
  };
}

export function setFormWordCharacter(
  formModel: FormModel,
  fillState: FormFillState,
  displayEntryId: string,
  formWordOffset: number,
  value: string,
): FormFillState {
  const displayEntry = getDisplayEntryById(formModel, displayEntryId);
  if (!displayEntry) {
    return fillState;
  }

  const formWord = getFormWordById(formModel, displayEntry.formWordId);
  if (!formWord) {
    return fillState;
  }

  const currentFill =
    fillState.fillsByFormWordId[displayEntry.formWordId] ??
    "_".repeat(formWord.length);

  const chars = currentFill.split("");
  if (formWordOffset < 0 || formWordOffset >= chars.length) {
    return fillState;
  }

  chars[formWordOffset] = value || "_";

  return {
    fillsByFormWordId: {
      ...fillState.fillsByFormWordId,
      [displayEntry.formWordId]: chars.join(""),
    },
  };
}

export function getFormWordOffsetForDisplayEntryCell(
  formModel: FormModel,
  displayEntryId: string,
  cellId: string,
): number {
  const displayEntry = getDisplayEntryById(formModel, displayEntryId);
  if (!displayEntry) {
    return -1;
  }

  return displayEntry.cellIds.indexOf(cellId);
}
