import { useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent } from "react";
import { CluePanel } from "../components/CluePanel";
import { WordLookupDialog } from "../components/WordLookupDialog";
import { MetadataPanel } from "../components/MetadataPanel";
import { PuzzleGrid, type PuzzleGridHandle } from "../components/PuzzleGrid";
import { Toolbar } from "../components/Toolbar";
import { buildEmptyContent, buildTopology } from "../domain/squareTopology";
import {
  findMatchingWords,
  parseWordListText,
  type LoadedWordList,
} from "../domain/wordList";
import { autofillGrid, type AutofillProgress } from "../domain/autofill";
import {
  applyWordToDisplayEntry,
  buildCellFillsFromFormFillState,
  buildEmptyFormFillState,
  buildFormModelFromTopology,
  formModelRoundTripMatchesCellFills,
  getDisplayEntryPatternById,
  getFormWordOffsetForDisplayEntryCell,
  setFormWordCharacter,
} from "../domain/formModel";
import type {
  AppMode,
  EntryDirection,
  EntryRef,
  SavedPuzzle,
  ShapeFamily,
  ShapeVariant,
  Topology,
} from "../domain/types";
import {
  downloadPuzzleFile,
  downloadSolverPuzzleFile,
  readPuzzleFile,
} from "../io/puzzleFile";
import {
  createInitialPuzzleStore,
  getEntryForCell,
  toggleDirectionForRepeatedCellClick,
} from "../state/puzzleStore";
import "../styles/app.css";

const WORD_LOOKUP_PAGE_SIZE = 100;

function getCellById(topology: Topology, cellId: string | null) {
  if (!cellId) {
    return undefined;
  }
  return topology.cells.find((cell) => cell.id === cellId);
}

function getEntryIndex(
  entries: EntryRef[],
  entryId: string | undefined,
): number {
  if (!entryId) {
    return -1;
  }
  return entries.findIndex((entry) => entry.id === entryId);
}

function getWrappedEntry(
  entries: EntryRef[],
  currentIndex: number,
  step: 1 | -1,
): EntryRef | undefined {
  if (entries.length === 0 || currentIndex < 0) {
    return undefined;
  }

  const nextIndex = (currentIndex + step + entries.length) % entries.length;
  return entries[nextIndex];
}

function getNextCellIdInEntry(
  entry: EntryRef | undefined,
  currentCellId: string | null,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  return (
    entry.cells[Math.min(index + 1, entry.cells.length - 1)] ?? currentCellId
  );
}

function getPreviousCellIdInEntry(
  entry: EntryRef | undefined,
  currentCellId: string | null,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  return entry.cells[Math.max(index - 1, 0)] ?? currentCellId;
}

function getNextSolveCellId(
  entry: EntryRef | undefined,
  currentCellId: string | null,
  fillsByCellIdBefore: Record<string, string>,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  const currentWasBlank = (fillsByCellIdBefore[currentCellId] ?? "") === "";

  if (!currentWasBlank) {
    return (
      entry.cells[Math.min(index + 1, entry.cells.length - 1)] ?? currentCellId
    );
  }

  for (let i = index + 1; i < entry.cells.length; i += 1) {
    const cellId = entry.cells[i];
    if ((fillsByCellIdBefore[cellId] ?? "") === "") {
      return cellId;
    }
  }

  for (let i = index + 1; i < entry.cells.length; i += 1) {
    const cellId = entry.cells[i];
    if ((fillsByCellIdBefore[cellId] ?? "") !== "") {
      return cellId;
    }
  }

  return currentCellId;
}

function buildSavedPuzzle(
  store: ReturnType<typeof createInitialPuzzleStore>,
): SavedPuzzle {
  return {
    version: 1,
    spec: store.spec,
    topology: store.topology,
    content: store.content,
    state: store.state,
    solution: store.solution,
  };
}

export default function App() {
  const [store, setStore] = useState(() => createInitialPuzzleStore(5));
  const gridRef = useRef<PuzzleGridHandle | null>(null);
  const [isDirty, setIsDirty] = useState(false);
  const [loadedWordList, setLoadedWordList] = useState<LoadedWordList | null>(
    null,
  );
  const [loadedPuzzleFileName, setLoadedPuzzleFileName] = useState<
    string | null
  >(null);
  const [loadedWordListName, setLoadedWordListName] = useState<string | null>(
    null,
  );
  const [lockCompletedWords, setLockCompletedWords] = useState(true);
  const [randomizeAutofillChoices, setRandomizeAutofillChoices] =
    useState(true);
  const [isAutofillRunning, setIsAutofillRunning] = useState(false);
  const [autofillStatusText, setAutofillStatusText] =
    useState("Autofill idle.");
  const [uiStatusText, setUiStatusText] = useState("Ready.");
  const [uiStatusKind, setUiStatusKind] = useState<
    "info" | "success" | "error"
  >("info");
  const autofillShouldContinueRef = useRef(true);
  const [isWordLookupOpen, setIsWordLookupOpen] = useState(false);
  const [wordLookupMatches, setWordLookupMatches] = useState<string[]>([]);
  const [wordLookupTotal, setWordLookupTotal] = useState(0);
  const [wordLookupOffset, setWordLookupOffset] = useState(0);
  const isConstruct = store.mode === "construct";
  const isSolve = store.mode === "solve";
  const currentShapeVariant: ShapeVariant =
    store.spec.shapeVariant ??
    (store.spec.shapeFamily === "windmill" ? "left" : "standard");

  const availableShapeVariants: ShapeVariant[] =
    store.spec.shapeFamily === "windmill" ? ["left", "right"] : ["standard"];

  useEffect(() => {
    function handleBeforeUnload(event: BeforeUnloadEvent) {
      if (!isDirty) {
        return;
      }

      event.preventDefault();
      event.returnValue = "";
    }

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isDirty]);

  function confirmDiscardChanges(actionDescription: string): boolean {
    if (!isDirty) {
      return true;
    }

    return window.confirm(
      `You have unsaved changes. Discard them and ${actionDescription}?`,
    );
  }

  function setUiStatus(
    text: string,
    kind: "info" | "success" | "error" = "info",
  ) {
    setUiStatusText(text);
    setUiStatusKind(kind);
  }

  const activeEntry = useMemo(() => {
    if (!store.selection.cellId) {
      return undefined;
    }

    return getEntryForCell(
      store.topology,
      store.selection.cellId,
      store.selection.direction,
    );
  }, [store.selection, store.topology]);

  const activeEntryPattern = useMemo(() => {
    if (!activeEntry) {
      return "";
    }

    return getDisplayEntryPatternById(formModel, formFillState, activeEntry.id);
  }, [activeEntry, formModel, formFillState]);

  const cluesByEntryId = useMemo(() => {
    return Object.fromEntries(
      store.content.clues.map((clue) => [clue.entryId, clue.text]),
    );
  }, [store.content.clues]);

  const acrossEntries = useMemo(
    () =>
      store.topology.entries.filter((entry) => entry.direction === "across"),
    [store.topology.entries],
  );

  const downEntries = useMemo(
    () => store.topology.entries.filter((entry) => entry.direction === "down"),
    [store.topology.entries],
  );

  const clueNumberByCellId = useMemo(() => {
    const map: Record<string, string> = {};

    for (const entry of acrossEntries) {
      const firstCellId = entry.cells[0];
      if (firstCellId) {
        map[firstCellId] = String(entry.number);
      }
    }

    for (const entry of downEntries) {
      const firstCellId = entry.cells[0];
      if (firstCellId && !map[firstCellId]) {
        map[firstCellId] = String(entry.number);
      }
    }

    return map;
  }, [acrossEntries, downEntries]);

  const formModel = useMemo(() => {
    return buildFormModelFromTopology(store.topology);
  }, [store.topology]);

  const formFillState = store.state;

  const projectedFillsByCellId = useMemo(() => {
    return buildCellFillsFromFormFillState(formModel, formFillState);
  }, [formModel, formFillState]);

  const formModelRoundTripOk = useMemo(() => {
    return formModelRoundTripMatchesCellFills(
      formModel,
      projectedFillsByCellId,
    );
  }, [formModel, projectedFillsByCellId]);

  void formModelRoundTripOk;

  function handleCellClick(cellId: string) {
    setStore((prev) => ({
      ...prev,
      selection: toggleDirectionForRepeatedCellClick(
        prev.topology,
        prev.selection,
        cellId,
      ),
    }));
  }

  function selectEntry(entry: EntryRef) {
    setStore((prev) => ({
      ...prev,
      selection: {
        cellId: entry.cells[0] ?? null,
        direction: entry.direction,
      },
    }));
  }

  function handleEntryClick(entryId: string) {
    const entry = store.topology.entries.find((e) => e.id === entryId);
    if (!entry) {
      return;
    }
    selectEntry(entry);
  }

  function moveToAdjacentEntry(step: 1 | -1) {
    if (!activeEntry) {
      return;
    }

    const entries =
      activeEntry.direction === "across" ? acrossEntries : downEntries;
    const index = getEntryIndex(entries, activeEntry.id);
    const nextEntry = getWrappedEntry(entries, index, step);
    if (!nextEntry) {
      return;
    }

    selectEntry(nextEntry);
  }

  function handleClueChange(entryId: string, text: string) {
    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        content: {
          ...prev.content,
          clues: prev.content.clues.map((clue) =>
            clue.entryId === entryId ? { ...clue, text } : clue,
          ),
        },
      };
    });

    if (store.mode === "construct") {
      setIsDirty(true);
    }
  }

  function handleSizeChange(size: number) {
    if (!confirmDiscardChanges("change the puzzle size")) {
      return;
    }

    const spec =
      store.spec.shapeFamily === "windmill"
        ? {
            shapeFamily: store.spec.shapeFamily,
            size,
            shapeVariant: currentShapeVariant,
          }
        : {
            shapeFamily: store.spec.shapeFamily,
            size,
            shapeVariant: "standard" as const,
          };
    const topology = buildTopology(spec);

    setStore({
      mode: "construct",
      spec,
      topology,
      content: buildEmptyContent(topology),
      state: buildEmptyFormFillState(buildFormModelFromTopology(topology)),
      solution: undefined,
      selection: {
        cellId: topology.cells[0]?.id ?? null,
        direction: "across",
      },
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleShapeFamilyChange(shapeFamily: ShapeFamily) {
    if (!confirmDiscardChanges("change the puzzle shape")) {
      return;
    }

    const spec =
      shapeFamily === "windmill"
        ? {
            shapeFamily,
            size: store.spec.size,
            shapeVariant:
              currentShapeVariant === "standard" ? "left" : currentShapeVariant,
          }
        : {
            shapeFamily,
            size: store.spec.size,
            shapeVariant: "standard" as const,
          };
    const topology = buildTopology(spec);

    setStore({
      mode: "construct",
      spec,
      topology,
      content: buildEmptyContent(topology),
      state: buildEmptyFormFillState(buildFormModelFromTopology(topology)),
      solution: undefined,
      selection: {
        cellId: topology.cells[0]?.id ?? null,
        direction: "across",
      },
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
    setUiStatus(`Started a new ${shapeFamily} puzzle.`, "success");
  }

  function handleShapeVariantChange(shapeVariant: ShapeVariant) {
    if (shapeVariant === currentShapeVariant) {
      return;
    }

    if (!confirmDiscardChanges("change the puzzle variant")) {
      return;
    }

    const spec =
      store.spec.shapeFamily === "windmill"
        ? {
            shapeFamily: "windmill" as const,
            size: store.spec.size,
            shapeVariant,
          }
        : {
            shapeFamily: store.spec.shapeFamily,
            size: store.spec.size,
            shapeVariant: "standard" as const,
          };

    const topology = buildTopology(spec);

    setStore({
      mode: "construct",
      spec,
      topology,
      content: buildEmptyContent(topology),
      state: buildEmptyFormFillState(buildFormModelFromTopology(topology)),
      solution: undefined,
      selection: {
        cellId: topology.cells[0]?.id ?? null,
        direction: "across",
      },
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);

    setUiStatus(
      store.spec.shapeFamily === "windmill"
        ? `Started a new ${shapeVariant} windmill puzzle.`
        : "Started a new puzzle variant.",
      "success",
    );
  }

  function handleNewPuzzle(size: number) {
    if (!confirmDiscardChanges("start a new puzzle")) {
      return;
    }

    setStore(
      createInitialPuzzleStore(
        size,
        store.spec.shapeFamily,
        currentShapeVariant,
      ),
    );
    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleModeChange(mode: AppMode) {
    setStore((prev) => ({ ...prev, mode }));
  }

  function handleCaptureSolution() {
    if (!isConstruct) {
      return;
    }

    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        solution: {
          fillsByFormWordId: { ...prev.state.fillsByFormWordId },
        },
      };
    });

    setIsDirty(true);
    setUiStatus("Solution captured.", "success");
  }

  function handleClearGrid() {
    setStore((prev) => ({
      ...prev,
      state: buildEmptyFormFillState(buildFormModelFromTopology(prev.topology)),
    }));

    setIsDirty(true);

    requestAnimationFrame(() => {
      gridRef.current?.focusGrid();
    });
  }

  function handleCheck() {
    if (!store.solution) {
      window.alert("No stored solution yet.");
      return;
    }

    const currentCellFills = buildCellFillsFromFormFillState(
      formModel,
      store.state,
    );
    const solutionCellFills = buildCellFillsFromFormFillState(
      formModel,
      store.solution,
    );

    const mismatches = Object.keys(solutionCellFills).filter((cellId) => {
      return (
        (currentCellFills[cellId] ?? "") !== (solutionCellFills[cellId] ?? "")
      );
    });

    if (mismatches.length === 0) {
      window.alert("Puzzle is correct.");
    } else {
      window.alert(
        `Puzzle is not yet correct. Mismatched cells: ${mismatches.length}`,
      );
    }
  }

  function handleSave() {
    const puzzle = buildSavedPuzzle(store);
    downloadPuzzleFile(puzzle);
    setIsDirty(false);
  }

  function handleExportSolverVersion() {
    if (!store.solution) {
      window.alert("Capture a solution before exporting a solver version.");
      return;
    }

    const solverPuzzle: SavedPuzzle = {
      version: 1,
      spec: store.spec,
      topology: store.topology,
      content: store.content,
      state: buildEmptyFormFillState(
        buildFormModelFromTopology(store.topology),
      ),
      solution: store.solution,
    };

    downloadSolverPuzzleFile(solverPuzzle);
  }

  async function handleLoad(file: File) {
    if (!confirmDiscardChanges("load another puzzle")) {
      return;
    }

    try {
      const puzzle = await readPuzzleFile(file);

      setStore((prev) => ({
        mode: prev.mode,
        spec: puzzle.spec,
        topology: puzzle.topology,
        content: puzzle.content,
        state: puzzle.state,
        solution: puzzle.solution,
        selection: {
          cellId: puzzle.topology.cells[0]?.id ?? null,
          direction: "across",
        },
      }));

      setLoadedPuzzleFileName(file.name);
      setIsDirty(false);
      setUiStatus(`Loaded puzzle: ${file.name}`, "success");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load puzzle file.";
      window.alert(message);
    }
  }

  async function handleLoadWordList(file: File) {
    try {
      const text = await file.text();
      const parsed = parseWordListText(text, file.name);
      setLoadedWordList(parsed);
      setLoadedWordListName(file.name);

      setUiStatus(
        `Loaded word list: ${parsed.name} (${parsed.eligibleEntries.length.toLocaleString()} eligible entries)`,
        "success",
      );
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to load word list file.";
      window.alert(message);
    }
  }

  function handleFindWords() {
    if (!activeEntry) {
      setUiStatus("No active entry selected.", "info");
      return;
    }

    if (!loadedWordList) {
      setUiStatus("No word list loaded.", "info");
      return;
    }

    if (!activeEntryPattern) {
      setUiStatus("Unable to derive a pattern for the active entry.", "error");
      return;
    }

    const result = findMatchingWords(
      loadedWordList,
      activeEntryPattern,
      0,
      WORD_LOOKUP_PAGE_SIZE,
    );

    if (result.total === 0) {
      setUiStatus(`No matches for pattern ${activeEntryPattern}.`, "info");
      return;
    }

    setWordLookupMatches(result.matches);
    setWordLookupTotal(result.total);
    setWordLookupOffset(result.matches.length);
    setIsWordLookupOpen(true);
    setUiStatus(
      `Found ${result.total.toLocaleString()} matches for pattern ${activeEntryPattern}.`,
      "success",
    );
  }

  async function handleAutofill() {
    if (!loadedWordList) {
      setUiStatus("No word list loaded.", "info");
      return;
    }

    if (isAutofillRunning) {
      return;
    }

    autofillShouldContinueRef.current = true;
    setIsAutofillRunning(true);
    setAutofillStatusText("Autofill running...");
    setUiStatus("Autofill running...", "info");
    await new Promise((resolve) => setTimeout(resolve, 0));

    try {
      const result = await autofillGrid(
        store.topology,
        store.state.fillsByCellId,
        loadedWordList,
        {
          lockCompletedWords,
          randomizeChoices: randomizeAutofillChoices,
        },
        {
          shouldContinue: () => autofillShouldContinueRef.current,
          onProgress: (progress: AutofillProgress) => {
            setAutofillStatusText(
              `Autofill running... nodes visited: ${progress.nodesVisited.toLocaleString()}`,
            );
          },
          progressInterval: 1000,
          yieldInterval: 250,
        },
      );

      if (!autofillShouldContinueRef.current) {
        setAutofillStatusText("Autofill cancelled.");
        setUiStatus("Autofill cancelled.", "info");
        return;
      }

      if (!result) {
        setAutofillStatusText("Autofill failed: no solution found.");
        setUiStatus("No autofill solution found.", "error");
        return;
      }

      setStore((prev) => ({
        ...prev,
        state: {
          fillsByCellId: result,
        },
      }));

      setIsDirty(true);
      setAutofillStatusText("Autofill succeeded.");
      setUiStatus("Autofill succeeded.", "success");

      requestAnimationFrame(() => {
        gridRef.current?.focusGrid();
      });
    } finally {
      setIsAutofillRunning(false);
    }
  }

  function handleStopAutofill() {
    autofillShouldContinueRef.current = false;
    setAutofillStatusText("Stopping autofill...");
    setUiStatus("Stopping autofill...", "info");
  }

  function handleLoadMoreWordLookupMatches() {
    if (!loadedWordList || !activeEntryPattern) {
      return;
    }

    const result = findMatchingWords(
      loadedWordList,
      activeEntryPattern,
      wordLookupOffset,
      WORD_LOOKUP_PAGE_SIZE,
    );

    setWordLookupMatches((prev) => [...prev, ...result.matches]);
    setWordLookupOffset((prev) => prev + result.matches.length);
  }

  function handleApplyWordLookupWord(word: string) {
    if (!activeEntry) {
      return;
    }

    const nextFormFillState = applyWordToDisplayEntry(
      formModel,
      formFillState,
      activeEntry.id,
      word,
    );

    const nextCellFills = buildCellFillsFromFormFillState(
      formModel,
      nextFormFillState,
    );

    setStore((prev) => ({
      ...prev,
      state: nextFormFillState,
    }));

    setIsDirty(true);
    setIsWordLookupOpen(false);
    setUiStatus(`Applied word: ${word}`, "success");

    requestAnimationFrame(() => {
      gridRef.current?.focusGrid();
    });
  }

  function handleCloseWordLookup() {
    setIsWordLookupOpen(false);
  }

  function handleTitleChange(title: string) {
    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        content: {
          ...prev.content,
          metadata: {
            ...prev.content.metadata,
            title,
          },
        },
      };
    });

    if (store.mode === "construct") {
      setIsDirty(true);
    }
  }

  function handleAuthorChange(author: string) {
    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        content: {
          ...prev.content,
          metadata: {
            ...prev.content.metadata,
            author,
          },
        },
      };
    });

    if (store.mode === "construct") {
      setIsDirty(true);
    }
  }

  function moveSelectionByArrow(
    direction: EntryDirection,
    deltaRow: number,
    deltaCol: number,
  ) {
    setStore((prev) => {
      const currentCell = getCellById(prev.topology, prev.selection.cellId);
      if (!currentCell) {
        return prev;
      }

      let candidateCells;

      if (deltaCol !== 0) {
        candidateCells = prev.topology.cells
          .filter((cell) => cell.row === currentCell.row)
          .sort((a, b) => a.col - b.col);

        const index = candidateCells.findIndex(
          (cell) => cell.id === currentCell.id,
        );
        if (index < 0 || candidateCells.length === 0) {
          return prev;
        }

        const step = deltaCol > 0 ? 1 : -1;
        const nextIndex =
          (index + step + candidateCells.length) % candidateCells.length;
        const nextCell = candidateCells[nextIndex];

        return {
          ...prev,
          selection: {
            cellId: nextCell.id,
            direction,
          },
        };
      }

      candidateCells = prev.topology.cells
        .filter((cell) => cell.col === currentCell.col)
        .sort((a, b) => a.row - b.row);

      const index = candidateCells.findIndex(
        (cell) => cell.id === currentCell.id,
      );
      if (index < 0 || candidateCells.length === 0) {
        return prev;
      }

      const step = deltaRow > 0 ? 1 : -1;
      const nextIndex =
        (index + step + candidateCells.length) % candidateCells.length;
      const nextCell = candidateCells[nextIndex];

      return {
        ...prev,
        selection: {
          cellId: nextCell.id,
          direction,
        },
      };
    });
  }

  function handleGridKeyDown(event: KeyboardEvent<SVGSVGElement>) {
    const key = event.key;

    if (key === "Tab") {
      event.preventDefault();
      moveToAdjacentEntry(event.shiftKey ? -1 : 1);
      return;
    }

    if (key === "Enter") {
      event.preventDefault();
      moveToAdjacentEntry(1);
      return;
    }

    if (key === "ArrowLeft") {
      event.preventDefault();
      moveSelectionByArrow("across", 0, -1);
      return;
    }

    if (key === "ArrowRight") {
      event.preventDefault();
      moveSelectionByArrow("across", 0, 1);
      return;
    }

    if (key === "ArrowUp") {
      event.preventDefault();
      moveSelectionByArrow("down", -1, 0);
      return;
    }

    if (key === "ArrowDown") {
      event.preventDefault();
      moveSelectionByArrow("down", 1, 0);
      return;
    }

    if (key === "Backspace") {
      event.preventDefault();

      setStore((prev) => {
        if (!prev.selection.cellId) {
          return prev;
        }

        const entry = getEntryForCell(
          prev.topology,
          prev.selection.cellId,
          prev.selection.direction,
        );
        if (!entry) {
          return prev;
        }

        const currentFormModel = buildFormModelFromTopology(prev.topology);
        const currentFormFillState = prev.state;

        const formWordOffset = getFormWordOffsetForDisplayEntryCell(
          currentFormModel,
          entry.id,
          prev.selection.cellId,
        );
        if (formWordOffset < 0) {
          return prev;
        }

        const nextFormFillState = setFormWordCharacter(
          currentFormModel,
          currentFormFillState,
          entry.id,
          formWordOffset,
          "",
        );

        return {
          ...prev,
          state: nextFormFillState,
          selection: {
            ...prev.selection,
            cellId: getPreviousCellIdInEntry(entry, prev.selection.cellId),
          },
        };
      });

      setIsDirty(true);
      return;
    }

    if (/^[a-zA-Z]$/.test(key)) {
      event.preventDefault();

      const letter = key.toUpperCase();

      setStore((prev) => {
        if (!prev.selection.cellId) {
          return prev;
        }

        const entry = getEntryForCell(
          prev.topology,
          prev.selection.cellId,
          prev.selection.direction,
        );
        if (!entry) {
          return prev;
        }

        const fillsBefore = buildCellFillsFromFormFillState(
          formModel,
          prev.state,
        );
        const currentFormModel = buildFormModelFromTopology(prev.topology);
        const currentFormFillState = prev.state;

        const formWordOffset = getFormWordOffsetForDisplayEntryCell(
          currentFormModel,
          entry.id,
          prev.selection.cellId,
        );
        if (formWordOffset < 0) {
          return prev;
        }

        const nextFormFillState = setFormWordCharacter(
          currentFormModel,
          currentFormFillState,
          entry.id,
          formWordOffset,
          letter,
        );

        const nextCellId =
          prev.mode === "solve"
            ? getNextSolveCellId(entry, prev.selection.cellId, fillsBefore)
            : getNextCellIdInEntry(entry, prev.selection.cellId);

        return {
          ...prev,
          state: nextFormFillState,
          selection: {
            ...prev.selection,
            cellId: nextCellId,
          },
        };
      });

      setIsDirty(true);
    }
  }

  function handleClueInputKeyDown(
    event: React.KeyboardEvent<HTMLInputElement>,
    entryId: string,
  ) {
    const entry = store.topology.entries.find((e) => e.id === entryId);
    if (!entry) {
      return;
    }

    if (keyIsNavigation(event.key)) {
      return;
    }

    if (event.key === "Tab") {
      event.preventDefault();
      const entries =
        entry.direction === "across" ? acrossEntries : downEntries;
      const index = getEntryIndex(entries, entry.id);
      const nextEntry = getWrappedEntry(
        entries,
        index,
        event.shiftKey ? -1 : 1,
      );
      if (nextEntry) {
        selectEntry(nextEntry);
      }
      return;
    }

    if (event.key === "Enter") {
      event.preventDefault();
      const entries =
        entry.direction === "across" ? acrossEntries : downEntries;
      const index = getEntryIndex(entries, entry.id);
      const nextEntry = getWrappedEntry(entries, index, 1);
      if (nextEntry) {
        selectEntry(nextEntry);
      }
    }
  }

  function keyIsNavigation(key: string): boolean {
    return (
      key === "ArrowLeft" ||
      key === "ArrowRight" ||
      key === "ArrowUp" ||
      key === "ArrowDown"
    );
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>Form Friend{isDirty ? " *" : ""}</h1>
      </header>

      <main className="app-main">
        <aside className="left-panel">
          <Toolbar
            size={store.spec.size}
            shapeFamily={store.spec.shapeFamily}
            shapeVariant={currentShapeVariant}
            availableShapeVariants={availableShapeVariants}
            onShapeFamilyChange={handleShapeFamilyChange}
            onShapeVariantChange={handleShapeVariantChange}
            mode={store.mode}
            hasSolution={Boolean(store.solution)}
            wordListEntryCount={loadedWordList?.eligibleEntries.length ?? 0}
            loadedPuzzleFileName={loadedPuzzleFileName}
            loadedWordListName={loadedWordListName}
            lockCompletedWords={lockCompletedWords}
            randomizeAutofillChoices={randomizeAutofillChoices}
            isAutofillRunning={isAutofillRunning}
            autofillStatusText={autofillStatusText}
            uiStatusText={uiStatusText}
            uiStatusKind={uiStatusKind}
            onNewPuzzle={handleNewPuzzle}
            onSizeChange={handleSizeChange}
            onModeChange={handleModeChange}
            onCaptureSolution={handleCaptureSolution}
            onClearGrid={handleClearGrid}
            onCheck={handleCheck}
            onSave={handleSave}
            onExportSolverVersion={handleExportSolverVersion}
            onLoad={handleLoad}
            onFindWords={handleFindWords}
            onLoadWordList={handleLoadWordList}
            onAutofill={handleAutofill}
            onStopAutofill={handleStopAutofill}
            onLockCompletedWordsChange={setLockCompletedWords}
            onRandomizeAutofillChoicesChange={setRandomizeAutofillChoices}
          />

          <MetadataPanel
            title={store.content.metadata.title}
            author={store.content.metadata.author}
            readOnly={isSolve}
            onTitleChange={handleTitleChange}
            onAuthorChange={handleAuthorChange}
          />
        </aside>

        <section className="center-panel">
          <PuzzleGrid
            ref={gridRef}
            topology={store.topology}
            fillsByCellId={projectedFillsByCellId}
            selection={store.selection}
            activeEntry={activeEntry}
            clueNumberByCellId={clueNumberByCellId}
            onCellClick={handleCellClick}
            onKeyDown={handleGridKeyDown}
          />
        </section>

        <aside className="right-panel">
          <CluePanel
            title="Across"
            entries={acrossEntries}
            cluesByEntryId={cluesByEntryId}
            activeEntryId={
              activeEntry?.direction === "across" ? activeEntry.id : undefined
            }
            readOnly={isSolve}
            onEntryClick={handleEntryClick}
            onEntryKeyDown={handleClueInputKeyDown}
            onClueChange={handleClueChange}
          />

          <CluePanel
            title="Down"
            entries={downEntries}
            cluesByEntryId={cluesByEntryId}
            activeEntryId={
              activeEntry?.direction === "down" ? activeEntry.id : undefined
            }
            readOnly={isSolve}
            onEntryClick={handleEntryClick}
            onEntryKeyDown={handleClueInputKeyDown}
            onClueChange={handleClueChange}
          />
        </aside>
      </main>
      <WordLookupDialog
        isOpen={isWordLookupOpen}
        pattern={activeEntryPattern}
        totalMatches={wordLookupTotal}
        matches={wordLookupMatches}
        canLoadMore={wordLookupMatches.length < wordLookupTotal}
        onApply={handleApplyWordLookupWord}
        onLoadMore={handleLoadMoreWordLookupMatches}
        onClose={handleCloseWordLookup}
      />
    </div>
  );
}
