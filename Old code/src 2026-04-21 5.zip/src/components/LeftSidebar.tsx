import { DesignerSidebar } from "../components/DesignerSidebar";
import { Toolbar } from "../components/Toolbar";
import type { AppMode, FormStyle, ShapeVariant } from "../domain/types";
import type { ComposedShapeDefinition } from "../domain/shapeDefinition";

type LeftSidebarProps = {
  isDesigner: boolean;
  storeMode: AppMode;
  size: number;
  allowedSizes: number[];
  currentShapeVariant: ShapeVariant;
  currentFormStyle: FormStyle;
  currentInverted: boolean;
  canBeSingle: boolean;
  currentShapeSupportsInversion: boolean;
  currentShapeSupportsLeftRight: boolean;
  formTypeTitle: string;
  shapeDisplayName?: string;
  sessionShapeLibrary: ComposedShapeDefinition[];
  selectedLibraryShapeId: string | null;
  loadedWordListEntryCount: number;
  loadedPuzzleFileName: string | null;
  loadedWordListName: string | null;
  lockCompletedWords: boolean;
  randomizeAutofillChoices: boolean;
  isAutofillRunning: boolean;
  autofillStatusText: string;
  isConstruct: boolean;
  isSolveStrict: boolean;
  isSolveCheckable: boolean;
  hasSolution: boolean;
  designerState: {
    name: string;
    size: number;
    layout: {
      width: number;
      height: number;
      overlapRows: number;
      overlapCols: number;
    };
  };
  safeDesignerPrimitiveSize: number;
  minimumDesignerPrimitiveSize: number;
  designerGridPresentation: "square" | "hex";
  onInstantiateLibraryShape: (definition: ComposedShapeDefinition) => void;
  onShapeVariantChange: (shapeVariant: ShapeVariant) => void;
  onInvertedChange: (inverted: boolean) => void;
  onFormStyleChange: (formStyle: FormStyle) => void;
  onNewPuzzle: (size: number) => void;
  onSizeChange: (size: number) => void;
  onModeChange: (mode: AppMode) => void;
  onCaptureSolution: () => void;
  onClearGrid: () => void;
  onCheck: () => void;
  onSave: () => void;
  onExportSolverVersion: () => void;
  onLoad: (file: File) => void | Promise<void>;
  onBrowseLibrary: () => void;
  onFindWords: () => void;
  onLoadWordList: (file: File) => void | Promise<void>;
  onAutofill: () => void | Promise<void>;
  onStopAutofill: () => void;
  onLockCompletedWordsChange: (value: boolean) => void;
  onRandomizeAutofillChoicesChange: (value: boolean) => void;
  onDesignerStateChange: (
    updater: (
      prev: LeftSidebarProps["designerState"],
    ) => LeftSidebarProps["designerState"],
  ) => void;
  onDesignerGridPresentationChange: (value: "square" | "hex") => void;
  onUseDesignedShape: () => void;
  onSaveDesignedShape: () => void;
  onClearDesignedGrid: () => void;
  onLoadDesignedShape: (file: File) => void | Promise<void>;
};

export function LeftSidebar({
  isDesigner,
  storeMode,
  size,
  allowedSizes,
  currentShapeVariant,
  currentFormStyle,
  currentInverted,
  canBeSingle,
  currentShapeSupportsInversion,
  currentShapeSupportsLeftRight,
  formTypeTitle,
  shapeDisplayName,
  sessionShapeLibrary,
  selectedLibraryShapeId,
  loadedWordListEntryCount,
  loadedPuzzleFileName,
  loadedWordListName,
  lockCompletedWords,
  randomizeAutofillChoices,
  isAutofillRunning,
  autofillStatusText,
  isConstruct,
  isSolveStrict,
  isSolveCheckable,
  hasSolution,
  designerState,
  safeDesignerPrimitiveSize,
  minimumDesignerPrimitiveSize,
  designerGridPresentation,
  onInstantiateLibraryShape,
  onShapeVariantChange,
  onInvertedChange,
  onFormStyleChange,
  onNewPuzzle,
  onSizeChange,
  onModeChange,
  onCaptureSolution,
  onClearGrid,
  onCheck,
  onSave,
  onExportSolverVersion,
  onLoad,
  onBrowseLibrary,
  onFindWords,
  onLoadWordList,
  onAutofill,
  onStopAutofill,
  onLockCompletedWordsChange,
  onRandomizeAutofillChoicesChange,
  onDesignerStateChange,
  onDesignerGridPresentationChange,
  onUseDesignedShape,
  onSaveDesignedShape,
  onClearDesignedGrid,
  onLoadDesignedShape,
}: LeftSidebarProps) {
  return (
    <aside className="left-panel">
      {!isDesigner ? (
        <>
          <Toolbar
            size={size}
            allowedSizes={allowedSizes}
            shapeVariant={currentShapeVariant}
            formStyle={currentFormStyle}
            inverted={currentInverted}
            canBeSingle={canBeSingle}
            supportsInverted={currentShapeSupportsInversion}
            formTypeTitle={formTypeTitle}
            supportsShapeVariantToggle={currentShapeSupportsLeftRight}
            shapeDisplayName={shapeDisplayName}
            libraryShapeOptions={sessionShapeLibrary.map((shape) => ({
              id: shape.id,
              name: shape.name,
            }))}
            selectedLibraryShapeId={selectedLibraryShapeId}
            onLibraryShapeChange={(shapeId) => {
              const definition = sessionShapeLibrary.find(
                (item) => item.id === shapeId,
              );
              if (!definition) {
                return;
              }

              onInstantiateLibraryShape(definition);
            }}
            onShapeVariantChange={onShapeVariantChange}
            onInvertedChange={onInvertedChange}
            onFormStyleChange={onFormStyleChange}
            mode={storeMode}
            isConstruct={isConstruct}
            isSolveStrict={isSolveStrict}
            isSolveCheckable={isSolveCheckable}
            hasSolution={hasSolution}
            wordListEntryCount={loadedWordListEntryCount}
            loadedPuzzleFileName={loadedPuzzleFileName}
            loadedWordListName={loadedWordListName}
            lockCompletedWords={lockCompletedWords}
            randomizeAutofillChoices={randomizeAutofillChoices}
            isAutofillRunning={isAutofillRunning}
            autofillStatusText={autofillStatusText}
            onNewPuzzle={onNewPuzzle}
            onSizeChange={onSizeChange}
            onModeChange={onModeChange}
            onCaptureSolution={onCaptureSolution}
            onClearGrid={onClearGrid}
            onCheck={onCheck}
            onSave={onSave}
            onExportSolverVersion={onExportSolverVersion}
            onLoad={onLoad}
            onBrowseLibrary={onBrowseLibrary}
            onFindWords={onFindWords}
            onLoadWordList={onLoadWordList}
            onAutofill={onAutofill}
            onStopAutofill={onStopAutofill}
            onLockCompletedWordsChange={onLockCompletedWordsChange}
            onRandomizeAutofillChoicesChange={onRandomizeAutofillChoicesChange}
          />
          {null}
        </>
      ) : (
        <>
          <DesignerSidebar
            shapeName={designerState.name}
            primitiveSize={safeDesignerPrimitiveSize}
            minimumPrimitiveSize={minimumDesignerPrimitiveSize}
            gridPresentation={designerGridPresentation}
            width={designerState.layout.width}
            height={designerState.layout.height}
            overlapRows={designerState.layout.overlapRows}
            overlapCols={designerState.layout.overlapCols}
            onShapeNameChange={(value) =>
              onDesignerStateChange((prev) => ({
                ...prev,
                name: value,
              }))
            }
            onPrimitiveSizeChange={(value) =>
              onDesignerStateChange((prev) => ({
                ...prev,
                size: value,
              }))
            }
            onGridPresentationChange={onDesignerGridPresentationChange}
            onWidthChange={(value) =>
              onDesignerStateChange((prev) => ({
                ...prev,
                layout: {
                  ...prev.layout,
                  width: value,
                },
              }))
            }
            onHeightChange={(value) =>
              onDesignerStateChange((prev) => ({
                ...prev,
                layout: {
                  ...prev.layout,
                  height: value,
                },
              }))
            }
            onOverlapRowsChange={(value) =>
              onDesignerStateChange((prev) => {
                const minimumSize =
                  Math.max(value, prev.layout.overlapCols) + 1;

                return {
                  ...prev,
                  size: Math.max(prev.size, minimumSize),
                  layout: {
                    ...prev.layout,
                    overlapRows: value,
                  },
                };
              })
            }
            onOverlapColsChange={(value) =>
              onDesignerStateChange((prev) => {
                const minimumSize =
                  Math.max(prev.layout.overlapRows, value) + 1;

                return {
                  ...prev,
                  size: Math.max(prev.size, minimumSize),
                  layout: {
                    ...prev.layout,
                    overlapCols: value,
                  },
                };
              })
            }
            onConstruct={onUseDesignedShape}
            onSaveShape={onSaveDesignedShape}
            onClearGrid={onClearDesignedGrid}
            onLoadShape={onLoadDesignedShape}
          />
          {null}
        </>
      )}
    </aside>
  );
}
