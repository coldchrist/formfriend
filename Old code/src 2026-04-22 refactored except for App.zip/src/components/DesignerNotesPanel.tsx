type DesignerNotesPanelProps = {
  layoutRowsText: string;
};

export function DesignerNotesPanel({
  layoutRowsText,
}: DesignerNotesPanelProps) {
  return (
    <section className="clue-panel" style={{ flex: 1, minHeight: 0 }}>
      <h3>Designer Notes</h3>
      <div className="clue-list" style={{ flex: 1, minHeight: 0 }}>
        <p>
          This first phase lets you place square and halfsquare primitives on a
          unified design surface.
        </p>
        <p>Library save/load and constructor handoff come next.</p>
        <p>
          Current layout:
          <br />
          <code>{layoutRowsText}</code>
        </p>
      </div>
    </section>
  );
}
