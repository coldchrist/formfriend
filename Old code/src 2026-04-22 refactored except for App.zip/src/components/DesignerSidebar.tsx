import { useRef } from "react";

type DesignerSidebarProps = {
  shapeName: string;
  primitiveSize: number;
  minimumPrimitiveSize: number;
  gridPresentation: "square" | "hex";
  width: number;
  height: number;
  overlapRows: number;
  overlapCols: number;
  onShapeNameChange: (value: string) => void;
  onPrimitiveSizeChange: (value: number) => void;
  onGridPresentationChange: (value: "square" | "hex") => void;
  onWidthChange: (value: number) => void;
  onHeightChange: (value: number) => void;
  onOverlapRowsChange: (value: number) => void;
  onOverlapColsChange: (value: number) => void;
  onConstruct: () => void;
  onSaveShape: () => void;
  onClearGrid: () => void;
  onLoadShape: (file: File) => void | Promise<void>;
};

export function DesignerSidebar({
  shapeName,
  primitiveSize,
  minimumPrimitiveSize,
  gridPresentation,
  width,
  height,
  overlapRows,
  overlapCols,
  onShapeNameChange,
  onPrimitiveSizeChange,
  onGridPresentationChange,
  onWidthChange,
  onHeightChange,
  onOverlapRowsChange,
  onOverlapColsChange,
  onConstruct,
  onSaveShape,
  onClearGrid,
  onLoadShape,
}: DesignerSidebarProps) {
  const loadShapeFileInputRef = useRef<HTMLInputElement | null>(null);

  return (
    <section className="clue-panel">
      <h3>Designer Settings</h3>

      <label style={{ display: "block", marginBottom: "0.75rem" }}>
        <span style={{ display: "block", marginBottom: "0.25rem" }}>
          Shape name
        </span>
        <input
          type="text"
          value={shapeName}
          onChange={(e) => onShapeNameChange(e.target.value)}
          style={{ width: "100%" }}
        />
      </label>

      <div
        style={{
          border: "1px solid #d1d5db",
          borderRadius: "0.5rem",
          padding: "0.75rem",
          marginBottom: "0.75rem",
        }}
      >
        <label style={{ display: "block", marginBottom: "0.75rem" }}>
          <span style={{ display: "block", marginBottom: "0.25rem" }}>
            Primitive size
          </span>
          <select
            value={primitiveSize}
            onChange={(e) => onPrimitiveSizeChange(Number(e.target.value))}
            style={{ width: "100%" }}
          >
            {Array.from({ length: 13 }, (_, index) => index + 3)
              .filter((size) => size >= minimumPrimitiveSize)
              .map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
          </select>
        </label>

        <label style={{ display: "block", marginBottom: "0.75rem" }}>
          <span style={{ display: "block", marginBottom: "0.25rem" }}>
            Grid display
          </span>
          <select
            value={gridPresentation}
            onChange={(e) =>
              onGridPresentationChange(e.target.value as "square" | "hex")
            }
            style={{ width: "100%" }}
          >
            <option value="square">Rectilinear</option>
            <option value="hex">Hex</option>
          </select>
        </label>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
            gap: "0.75rem",
          }}
        >
          <label style={{ display: "block" }}>
            <span style={{ display: "block", marginBottom: "0.25rem" }}>
              Width
            </span>
            <input
              type="number"
              min={1}
              max={12}
              value={width}
              onChange={(e) =>
                onWidthChange(Math.max(1, Number(e.target.value) || 1))
              }
              style={{ width: "100%" }}
            />
          </label>

          <label style={{ display: "block" }}>
            <span style={{ display: "block", marginBottom: "0.25rem" }}>
              Height
            </span>
            <input
              type="number"
              min={1}
              max={12}
              value={height}
              onChange={(e) =>
                onHeightChange(Math.max(1, Number(e.target.value) || 1))
              }
              style={{ width: "100%" }}
            />
          </label>

          <label style={{ display: "block" }}>
            <span
              style={{
                display: "block",
                marginBottom: "0.25rem",
                whiteSpace: "nowrap",
              }}
            >
              Row overlap
            </span>
            <select
              value={overlapRows}
              onChange={(e) => onOverlapRowsChange(Number(e.target.value))}
              style={{ width: "100%" }}
            >
              <option value={0}>0</option>
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
            </select>
          </label>

          <label style={{ display: "block" }}>
            <span
              style={{
                display: "block",
                marginBottom: "0.25rem",
                whiteSpace: "nowrap",
              }}
            >
              Column overlap
            </span>
            <select
              value={overlapCols}
              onChange={(e) => onOverlapColsChange(Number(e.target.value))}
              style={{ width: "100%" }}
            >
              <option value={0}>0</option>
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
            </select>
          </label>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
          gap: "0.5rem",
        }}
      >
        <button type="button" onClick={onConstruct}>
          Construct with This Shape
        </button>
        <button type="button" onClick={onSaveShape}>
          Save Shape
        </button>
        <button
          type="button"
          onClick={() => loadShapeFileInputRef.current?.click()}
        >
          Load Shape
        </button>
        <button type="button" onClick={onClearGrid}>
          Clear Grid
        </button>
      </div>

      <input
        ref={loadShapeFileInputRef}
        type="file"
        accept=".json,application/json"
        style={{ display: "none" }}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (!file) {
            return;
          }

          void onLoadShape(file);
          e.currentTarget.value = "";
        }}
      />
    </section>
  );
}
