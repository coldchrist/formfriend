import { PuzzleGrid, type PuzzleGridHandle } from "../components/PuzzleGrid";

type PuzzleCenterPanelProps = {
  gridRef: React.RefObject<PuzzleGridHandle | null>;
  isConstruct: boolean;
  isSolveCheckable: boolean;
  isSolutionCorrect: boolean;
  formTypeTitle: string;
  showAutofillBanner: boolean;
  autofillStatusText: string;
  metadata: {
    publication?: string;
    title: string;
    author: string;
  };
  projectedFillsByCellId: Record<string, string>;
  selection: {
    cellId: string | null;
    direction: "across" | "down";
  };
  activeGridCellIds: string[];
  clueNumberByCellId: Record<string, string>;
  gridPresentation: "square" | "hex";
  incorrectCellIds: Set<string>;
  topology: Parameters<typeof PuzzleGrid>[0]["topology"];
  onPublicationChange: (value: string) => void;
  onTitleChange: (value: string) => void;
  onAuthorChange: (value: string) => void;
  onCellClick: (cellId: string) => void;
  onKeyDown: (event: React.KeyboardEvent<SVGSVGElement>) => void;
};

export function PuzzleCenterPanel({
  gridRef,
  isConstruct,
  isSolveCheckable,
  isSolutionCorrect,
  formTypeTitle,
  showAutofillBanner,
  autofillStatusText,
  metadata,
  projectedFillsByCellId,
  selection,
  activeGridCellIds,
  clueNumberByCellId,
  gridPresentation,
  incorrectCellIds,
  topology,
  onPublicationChange,
  onTitleChange,
  onAuthorChange,
  onCellClick,
  onKeyDown,
}: PuzzleCenterPanelProps) {
  return (
    <>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr auto 1fr",
          alignItems: "center",
          marginBottom: "0.5rem",
          gap: "0.5rem",
        }}
      >
        <div
          style={{
            textAlign: "left",
            fontSize: "0.9rem",
            color: "#555",
          }}
        >
          {isConstruct ? (
            <input
              type="text"
              value={metadata.publication ?? ""}
              onChange={(e) => onPublicationChange(e.target.value)}
              style={{
                width: "100%",
                border: "none",
                borderBottom: "1px solid #ccc",
              }}
            />
          ) : (
            metadata.publication
          )}
        </div>

        <div
          style={{
            textAlign: "center",
            fontWeight: 600,
            fontSize: "1.1rem",
          }}
        >
          {isConstruct ? (
            <input
              type="text"
              value={metadata.title}
              onChange={(e) => onTitleChange(e.target.value)}
              style={{
                textAlign: "center",
                border: "none",
                borderBottom: "1px solid #ccc",
                width: "100%",
              }}
            />
          ) : (
            metadata.title
          )}
        </div>

        <div style={{ textAlign: "right", fontSize: "0.9rem" }}>
          {isConstruct ? (
            <input
              type="text"
              value={metadata.author}
              onChange={(e) => onAuthorChange(e.target.value)}
              style={{
                textAlign: "right",
                border: "none",
                borderBottom: "1px solid #ccc",
                width: "100%",
              }}
            />
          ) : (
            metadata.author
          )}
        </div>
      </div>

      <h3 className="center-title">{formTypeTitle}</h3>

      {showAutofillBanner ? (
        <div
          style={{
            display: "block",
            marginTop: "0.25rem",
            marginBottom: "0.75rem",
            fontStyle: "italic",
            textAlign: "center",
            fontWeight: 500,
            minHeight: "1.25rem",
          }}
        >
          {autofillStatusText.startsWith("Stopping autofill")
            ? "Stopping autofill..."
            : "Autofilling..."}
        </div>
      ) : null}

      <div className="grid-wrapper">
        <PuzzleGrid
          ref={gridRef}
          topology={topology}
          fillsByCellId={projectedFillsByCellId}
          selection={selection}
          activeCellIds={activeGridCellIds}
          clueNumberByCellId={clueNumberByCellId}
          gridPresentation={gridPresentation}
          incorrectCellIds={isSolveCheckable ? incorrectCellIds : new Set()}
          onCellClick={onCellClick}
          onKeyDown={onKeyDown}
        />
      </div>

      {isSolveCheckable && isSolutionCorrect ? (
        <div
          style={{
            textAlign: "center",
            marginTop: "0.5rem",
            color: "#15803d",
          }}
        >
          Solution is correct!
        </div>
      ) : null}
    </>
  );
}
