import type { DisplayEntry, FormModel } from "../domain/formModel";
import type {
  AppMode,
  EntryRef,
  FormStyle,
  SavedPuzzle,
  SolveMode,
  Topology,
} from "../domain/types";
import type { PuzzleStoreState } from "../state/puzzleStore";
import { isTopologyReflectableAcrossLeadingDiagonal } from "../domain/squareTopology";

export const WORD_LOOKUP_PAGE_SIZE = 100;

export function getCellById(topology: Topology, cellId: string | null) {
  if (!cellId) {
    return undefined;
  }
  return topology.cells.find((cell) => cell.id === cellId);
}

export function getEntryIndex(
  entries: EntryRef[],
  entryId: string | undefined,
): number {
  if (!entryId) {
    return -1;
  }
  return entries.findIndex((entry) => entry.id === entryId);
}

export function getWrappedEntry(
  entries: EntryRef[],
  currentIndex: number,
  step: 1 | -1,
): EntryRef | undefined {
  if (entries.length === 0 || currentIndex < 0) {
    return undefined;
  }

  const nextIndex = (currentIndex + step + entries.length) % entries.length;
  return entries[nextIndex];
}

export function getNextCellIdInEntry(
  entry: EntryRef | undefined,
  currentCellId: string | null,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  return (
    entry.cells[Math.min(index + 1, entry.cells.length - 1)] ?? currentCellId
  );
}

export function getPreviousCellIdInEntry(
  entry: EntryRef | undefined,
  currentCellId: string | null,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  return entry.cells[Math.max(index - 1, 0)] ?? currentCellId;
}

export function getNextSolveCellId(
  entry: EntryRef | undefined,
  currentCellId: string | null,
  fillsByCellIdBefore: Record<string, string>,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  const currentWasBlank = (fillsByCellIdBefore[currentCellId] ?? "") === "";

  if (!currentWasBlank) {
    return (
      entry.cells[Math.min(index + 1, entry.cells.length - 1)] ?? currentCellId
    );
  }

  for (let i = index + 1; i < entry.cells.length; i += 1) {
    const cellId = entry.cells[i];
    if ((fillsByCellIdBefore[cellId] ?? "") === "") {
      return cellId;
    }
  }

  for (let i = index + 1; i < entry.cells.length; i += 1) {
    const cellId = entry.cells[i];
    if ((fillsByCellIdBefore[cellId] ?? "") !== "") {
      return cellId;
    }
  }

  return currentCellId;
}

function compareCellsReadingOrder(
  left: { row: number; col: number },
  right: { row: number; col: number },
): number {
  if (left.row !== right.row) {
    return left.row - right.row;
  }

  return left.col - right.col;
}

function buildCellById(
  topology: Topology,
): Map<string, Topology["cells"][number]> {
  return new Map(topology.cells.map((cell) => [cell.id, cell]));
}

export function buildDoublePresentationNumbering(topology: Topology): {
  numberByEntryId: Record<string, number>;
  clueNumberByCellId: Record<string, string>;
} {
  const cellById = buildCellById(topology);
  const numberByEntryId: Record<string, number> = {};
  const clueNumberByCellId: Record<string, string> = {};

  const acrossStarts = new Map<string, EntryRef>();
  const downStarts = new Map<string, EntryRef>();

  for (const entry of topology.entries) {
    const startCellId = entry.cells[0];
    if (!startCellId) {
      continue;
    }

    if (entry.direction === "across") {
      acrossStarts.set(startCellId, entry);
    } else {
      downStarts.set(startCellId, entry);
    }
  }

  const startCellIds = [
    ...new Set([...acrossStarts.keys(), ...downStarts.keys()]),
  ];

  startCellIds.sort((leftId, rightId) => {
    const left = cellById.get(leftId);
    const right = cellById.get(rightId);

    if (!left || !right) {
      return 0;
    }

    return compareCellsReadingOrder(left, right);
  });

  let nextAcross = 1;
  let nextDown = 1;

  for (const startCellId of startCellIds) {
    const acrossEntry = acrossStarts.get(startCellId);
    const downEntry = downStarts.get(startCellId);

    if (acrossEntry && downEntry) {
      const number = Math.min(nextAcross, nextDown);
      numberByEntryId[acrossEntry.id] = number;
      numberByEntryId[downEntry.id] = number;
      clueNumberByCellId[startCellId] = String(number);
      nextAcross = number + 1;
      nextDown = number + 1;
      continue;
    }

    if (acrossEntry) {
      numberByEntryId[acrossEntry.id] = nextAcross;
      clueNumberByCellId[startCellId] = String(nextAcross);
      nextAcross += 1;
      continue;
    }

    if (downEntry) {
      numberByEntryId[downEntry.id] = nextDown;
      clueNumberByCellId[startCellId] = String(nextDown);
      nextDown += 1;
    }
  }

  return {
    numberByEntryId,
    clueNumberByCellId,
  };
}

export function buildSinglePresentationNumbering(
  formModel: FormModel,
  topology: Topology,
): {
  numberByEntryId: Record<string, number>;
  clueNumberByCellId: Record<string, string>;
  representativeEntryIds: string[];
  representativeEntryIdByFormWordId: Record<string, string>;
} {
  const cellById = buildCellById(topology);
  const grouped = new Map<string, DisplayEntry[]>();

  for (const entry of formModel.displayEntries) {
    const entries = grouped.get(entry.formWordId) ?? [];
    entries.push(entry);
    grouped.set(entry.formWordId, entries);
  }

  const groups = [...grouped.entries()].map(([formWordId, entries]) => {
    const sortedEntries = [...entries].sort((left, right) => {
      const leftCell = cellById.get(left.cellIds[0] ?? "");
      const rightCell = cellById.get(right.cellIds[0] ?? "");

      if (!leftCell || !rightCell) {
        return 0;
      }

      return compareCellsReadingOrder(leftCell, rightCell);
    });

    return {
      formWordId,
      entries: sortedEntries,
      representative: sortedEntries[0],
    };
  });

  groups.sort((left, right) => {
    const leftCell = cellById.get(left.representative.cellIds[0] ?? "");
    const rightCell = cellById.get(right.representative.cellIds[0] ?? "");

    if (!leftCell || !rightCell) {
      return 0;
    }

    return compareCellsReadingOrder(leftCell, rightCell);
  });

  const numberByEntryId: Record<string, number> = {};
  const clueNumberByCellId: Record<string, string> = {};
  const representativeEntryIds: string[] = [];
  const representativeEntryIdByFormWordId: Record<string, string> = {};

  groups.forEach((group, index) => {
    const number = index + 1;
    representativeEntryIds.push(group.representative.id);
    representativeEntryIdByFormWordId[group.formWordId] =
      group.representative.id;

    for (const entry of group.entries) {
      numberByEntryId[entry.id] = number;
      const startCellId = entry.cellIds[0];
      if (startCellId) {
        clueNumberByCellId[startCellId] = String(number);
      }
    }
  });

  return {
    numberByEntryId,
    clueNumberByCellId,
    representativeEntryIds,
    representativeEntryIdByFormWordId,
  };
}

export function relabelEntry(
  entry: EntryRef,
  number: number,
  single: boolean,
): EntryRef {
  return {
    ...entry,
    number,
    label: single
      ? String(number)
      : `${number}${entry.direction === "across" ? "A" : "D"}`,
  };
}

export function getFormTypeTitle(
  shapeVariant: import("../domain/types").ShapeVariant,
  formStyle: FormStyle,
  inverted: boolean,
  canBeSingle: boolean,
  supportsLeftRight: boolean,
  shapeName?: string,
): string {
  const parts: string[] = [];

  if (formStyle === "double" && canBeSingle) {
    parts.push("Double");
  }

  if (inverted) {
    parts.push("Inverted");
  }

  if (supportsLeftRight) {
    if (shapeVariant === "left") {
      parts.push("Left");
    } else if (shapeVariant === "right") {
      parts.push("Right");
    }
  }

  parts.push(shapeName?.trim() || "Composed Shape");
  return parts.join(" ");
}

export function getAllowedSizes(): number[] {
  return [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
}

export function resolveFormStyleForTopology(
  requestedFormStyle: FormStyle,
  topology: Topology,
): FormStyle {
  if (requestedFormStyle === "single") {
    return isTopologyReflectableAcrossLeadingDiagonal(topology)
      ? "single"
      : "double";
  }

  return "double";
}

export function getTodayString(): string {
  return new Date().toISOString().slice(0, 10);
}

export function getSolveModeForStoreMode(mode: AppMode): SolveMode {
  return mode === "solve_strict" ? "strict" : "checkable";
}

export function buildSavedPuzzle(
  store: PuzzleStoreState,
  metadata: {
    solveMode: SolveMode;
    dateAdded: string;
    comment: string;
    enigmaIssue: string;
    formNumber: string;
    gridPresentation: SavedPuzzle["gridPresentation"];
  },
  options?: {
    stateOverride?: SavedPuzzle["state"];
    solutionOverride?: SavedPuzzle["solution"];
  },
): SavedPuzzle {
  return {
    version: 1,
    spec: store.spec,
    topology: store.topology,
    content: store.content,
    state: options?.stateOverride ?? store.state,
    solution:
      options?.solutionOverride !== undefined
        ? options.solutionOverride
        : store.solution,
    solveMode: metadata.solveMode,
    gridPresentation: metadata.gridPresentation,
    dateAdded: metadata.dateAdded || getTodayString(),
    comment: metadata.comment.trim() || undefined,
    enigmaIssue: metadata.enigmaIssue.trim() || undefined,
    formNumber: metadata.formNumber.trim() || undefined,
  };
}
