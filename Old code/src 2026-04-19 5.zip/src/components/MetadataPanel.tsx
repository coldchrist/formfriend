type MetadataPanelProps = {
  title: string;
  author: string;
  readOnly?: boolean;
  onTitleChange: (value: string) => void;
  onAuthorChange: (value: string) => void;
};

export function MetadataPanel({
  title,
  author,
  readOnly = false,
  onTitleChange,
  onAuthorChange,
}: MetadataPanelProps) {
  return (
    <section className="metadata-panel">
      <label>
        Title
        <input
          type="text"
          value={title}
          disabled={readOnly}
          onChange={(e) => onTitleChange(e.target.value)}
        />
      </label>
      <label>
        Author
        <input
          type="text"
          value={author}
          disabled={readOnly}
          onChange={(e) => onAuthorChange(e.target.value)}
        />
      </label>
    </section>
  );
}
