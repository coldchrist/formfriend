import { buildEmptyContent, buildTopology } from "../domain/squareTopology";
import {
  buildEmptyFormFillState,
  buildFormModelFromTopology,
} from "../domain/formModel";
import type { ComposedShapeDefinition } from "../domain/shapeDefinition";
import { buildPuzzleSpecFromComposedShapeDefinition } from "../domain/shapeInstantiation";
import {
  DEFAULT_STANDARD_SHAPE_ID,
  getStandardShapeById,
} from "../domain/standardShapeLibrary";

import type {
  AppMode,
  EntryDirection,
  PuzzleContent,
  PuzzleSpec,
  PuzzleState,
  SelectionState,
  SolutionState,
  Topology,
  ShapeVariant,
  FormStyle,
} from "../domain/types";

export interface PuzzleStoreState {
  mode: AppMode;
  spec: PuzzleSpec;
  topology: Topology;
  content: PuzzleContent;
  state: PuzzleState;
  solution?: SolutionState;
  selection: SelectionState;
}

function getDefaultShapeDefinition(): ComposedShapeDefinition {
  const definition = getStandardShapeById(DEFAULT_STANDARD_SHAPE_ID);
  if (!definition) {
    throw new Error("Missing default standard shape definition.");
  }
  return definition;
}

export function createInitialPuzzleStore(
  size = 5,
  definition: ComposedShapeDefinition = getDefaultShapeDefinition(),
  shapeVariant: ShapeVariant = "left",
  formStyle: FormStyle = "double",
): PuzzleStoreState {
  const spec: PuzzleSpec = {
    ...buildPuzzleSpecFromComposedShapeDefinition(definition, size, formStyle),
    shapeVariant: shapeVariant === "right" ? "right" : "left",
    inverted: false,
  };

  const topology = buildTopology(spec);

  return {
    mode: "construct",
    spec,
    topology,
    content: buildEmptyContent(spec, topology),
    state: buildEmptyFormFillState(buildFormModelFromTopology(spec, topology)),
    solution: undefined,
    selection: {
      cellId: topology.cells[0]?.id ?? null,
      direction: "across",
    },
  };
}

export function getEntryForCell(
  topology: Topology,
  cellId: string,
  direction: EntryDirection,
) {
  return topology.entries.find(
    (entry) => entry.direction === direction && entry.cells.includes(cellId),
  );
}

export function toggleDirectionForRepeatedCellClick(
  topology: Topology,
  selection: SelectionState,
  clickedCellId: string,
): SelectionState {
  if (selection.cellId !== clickedCellId) {
    return {
      cellId: clickedCellId,
      direction: "across",
    };
  }

  const nextDirection: EntryDirection =
    selection.direction === "across" ? "down" : "across";

  const nextEntry = getEntryForCell(topology, clickedCellId, nextDirection);
  if (!nextEntry) {
    return selection;
  }

  return {
    cellId: clickedCellId,
    direction: nextDirection,
  };
}
