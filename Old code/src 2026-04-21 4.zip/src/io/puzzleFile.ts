import type { SavedPuzzle, SolveMode } from "../domain/types";

export function downloadPuzzleFile(puzzle: SavedPuzzle): void {
  const json = JSON.stringify(puzzle, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  try {
    const link = document.createElement("a");
    link.href = url;
    link.download = buildDownloadFileName(puzzle);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function downloadSolverPuzzleFile(puzzle: SavedPuzzle): void {
  const json = JSON.stringify(puzzle, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  try {
    const link = document.createElement("a");
    link.href = url;
    link.download = buildSolverDownloadFileName(puzzle);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function readPuzzleFile(file: File): Promise<SavedPuzzle> {
  const text = await file.text();
  const parsed = JSON.parse(text) as Partial<SavedPuzzle>;
  validateSavedPuzzle(parsed);

  return {
    ...parsed,
    solveMode: (parsed.solveMode ?? "checkable") as SolveMode,
    gridPresentation: parsed.gridPresentation === "hex" ? "hex" : "square",
    dateAdded:
      typeof parsed.dateAdded === "string" && parsed.dateAdded.trim() !== ""
        ? parsed.dateAdded
        : new Date().toISOString().slice(0, 10),
  } as SavedPuzzle;
}

function buildDownloadFileName(puzzle: SavedPuzzle): string {
  const rawTitle = puzzle.content.metadata.title?.trim() || "formfriend-puzzle";
  const safeTitle = rawTitle
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

  return `${safeTitle || "formfriend-puzzle"}.json`;
}

function buildSolverDownloadFileName(puzzle: SavedPuzzle): string {
  const rawTitle = puzzle.content.metadata.title?.trim() || "formfriend-puzzle";
  const safeTitle = rawTitle
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

  return `${safeTitle || "formfriend-puzzle"}-solver.json`;
}

function validateSavedPuzzle(puzzle: Partial<SavedPuzzle>): void {
  if (!puzzle || typeof puzzle !== "object") {
    throw new Error("Puzzle file is not a valid object.");
  }

  if (puzzle.version !== 1) {
    throw new Error(`Unsupported puzzle version: ${String(puzzle.version)}`);
  }

  if (!puzzle.spec || puzzle.spec.shapeFamily !== "composed") {
    throw new Error("Only composed-shape puzzles are currently supported.");
  }

  if (
    typeof puzzle.spec.composedLayout !== "string" ||
    puzzle.spec.composedLayout.trim() === ""
  ) {
    throw new Error("Puzzle file is missing composedLayout.");
  }

  if (!Number.isInteger(puzzle.spec.size) || puzzle.spec.size < 2) {
    throw new Error("Puzzle file has an invalid size.");
  }

  if (
    puzzle.spec.formStyle !== undefined &&
    puzzle.spec.formStyle !== "double" &&
    puzzle.spec.formStyle !== "single"
  ) {
    throw new Error("Puzzle file has an invalid form style.");
  }

  if (
    puzzle.spec.inverted !== undefined &&
    typeof puzzle.spec.inverted !== "boolean"
  ) {
    throw new Error("Puzzle file has an invalid inverted flag.");
  }

  if (
    !puzzle.topology ||
    !Array.isArray(puzzle.topology.cells) ||
    !Array.isArray(puzzle.topology.entries)
  ) {
    throw new Error("Puzzle file is missing topology.");
  }

  if (!puzzle.content || !Array.isArray(puzzle.content.clues)) {
    throw new Error("Puzzle file is missing clues.");
  }

  if (!puzzle.state || typeof puzzle.state.fillsByFormWordId !== "object") {
    throw new Error("Puzzle file is missing state.");
  }

  if (
    puzzle.solution &&
    typeof puzzle.solution.fillsByFormWordId !== "object"
  ) {
    throw new Error("Puzzle file has an invalid solution state.");
  }
  if (
    puzzle.solveMode !== undefined &&
    puzzle.solveMode !== "strict" &&
    puzzle.solveMode !== "checkable"
  ) {
    throw new Error("Puzzle file has an invalid solveMode.");
  }

  if (
    puzzle.gridPresentation !== undefined &&
    puzzle.gridPresentation !== "square" &&
    puzzle.gridPresentation !== "hex"
  ) {
    throw new Error("Puzzle file has an invalid gridPresentation.");
  }

  if (
    puzzle.dateAdded !== undefined &&
    (typeof puzzle.dateAdded !== "string" || puzzle.dateAdded.trim() === "")
  ) {
    throw new Error("Puzzle file has an invalid dateAdded.");
  }

  if (puzzle.comment !== undefined && typeof puzzle.comment !== "string") {
    throw new Error("Puzzle file has an invalid comment.");
  }

  if (
    puzzle.enigmaIssue !== undefined &&
    typeof puzzle.enigmaIssue !== "string"
  ) {
    throw new Error("Puzzle file has an invalid enigmaIssue.");
  }

  if (
    puzzle.formNumber !== undefined &&
    typeof puzzle.formNumber !== "string"
  ) {
    throw new Error("Puzzle file has an invalid formNumber.");
  }
}
