import type { ComposedShapeDefinition } from "./shapeDefinition";

/**
 * Canonical standard shapes expressed as composed layouts.
 * These are the replacements for the old built-in families.
 */

const STANDARD_SHAPES: ComposedShapeDefinition[] = [
  {
    kind: "composed",
    id: "square",
    name: "Square",
    layout: {
      width: 1,
      height: 1,
      rows: ["S"],
      overlapRows: 1,
      overlapCols: 1,
    },
  },
  {
    kind: "composed",
    id: "windmill",
    name: "Windmill",
    layout: {
      width: 2,
      height: 2,
      rows: ["S.", ".S"],
      overlapRows: 1,
      overlapCols: 1,
    },
  },
];

/**
 * Default shape used for new puzzles.
 */
export const DEFAULT_STANDARD_SHAPE_ID = "square";

export function getAllStandardShapes(): ComposedShapeDefinition[] {
  return STANDARD_SHAPES;
}

export function getStandardShapeById(
  id: string,
): ComposedShapeDefinition | undefined {
  return STANDARD_SHAPES.find((shape) => shape.id === id);
}
