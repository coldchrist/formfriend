import { forwardRef, useImperativeHandle, useRef } from "react";
import type { EntryRef, SelectionState, Topology } from "../domain/types";

export type PuzzleGridHandle = {
  focusGrid: () => void;
};

type PuzzleGridProps = {
  topology: Topology;
  fillsByCellId: Record<string, string>;
  selection: SelectionState;
  activeCellIds?: string[];
  clueNumberByCellId: Record<string, string>;
  onCellClick: (cellId: string) => void;
  onKeyDown: (event: React.KeyboardEvent<SVGSVGElement>) => void;
};

const CELL_SIZE = 48;
const PADDING = 16;

export const PuzzleGrid = forwardRef<PuzzleGridHandle, PuzzleGridProps>(
  function PuzzleGrid(
    {
      topology,
      fillsByCellId,
      selection,
      activeCellIds = [],
      clueNumberByCellId,
      onCellClick,
      onKeyDown,
    },
    ref,
  ) {
    const svgRef = useRef<SVGSVGElement | null>(null);

    useImperativeHandle(ref, () => ({
      focusGrid() {
        svgRef.current?.focus();
      },
    }));

    const maxRow = Math.max(...topology.cells.map((c) => c.row), 0);
    const maxCol = Math.max(...topology.cells.map((c) => c.col), 0);

    const width = PADDING * 2 + (maxCol + 1) * CELL_SIZE;
    const height = PADDING * 2 + (maxRow + 1) * CELL_SIZE;

    const activeCellIdSet = new Set(activeCellIds);

    return (
      <svg
        ref={svgRef}
        width={width}
        height={height}
        className="puzzle-grid"
        role="img"
        aria-label="Puzzle grid"
        tabIndex={0}
        onKeyDown={onKeyDown}
      >
        {topology.cells.map((cell) => {
          const x = PADDING + cell.col * CELL_SIZE;
          const y = PADDING + cell.row * CELL_SIZE;
          const isSelected = selection.cellId === cell.id;
          const isActive = activeCellIdSet.has(cell.id);
          const fill = isSelected ? "#cfe8ff" : isActive ? "#eaf4ff" : "white";
          const clueNumber = clueNumberByCellId[cell.id];

          return (
            <g
              key={cell.id}
              onClick={() => {
                onCellClick(cell.id);
                svgRef.current?.focus();
              }}
              style={{ cursor: "pointer" }}
            >
              <rect
                x={x}
                y={y}
                width={CELL_SIZE}
                height={CELL_SIZE}
                fill={fill}
                stroke="#333"
              />

              {clueNumber ? (
                <text
                  x={x + 4}
                  y={y + 10}
                  textAnchor="start"
                  fontSize="10"
                  fontFamily="Arial, sans-serif"
                  fill="#555"
                >
                  {clueNumber}
                </text>
              ) : null}

              <text
                x={x + CELL_SIZE / 2}
                y={y + CELL_SIZE / 2 + 8}
                textAnchor="middle"
                fontSize="24"
                fontFamily="Arial, sans-serif"
              >
                {fillsByCellId[cell.id] ?? ""}
              </text>
            </g>
          );
        })}
      </svg>
    );
  },
);
