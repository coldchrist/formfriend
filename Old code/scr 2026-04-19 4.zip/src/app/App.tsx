import { getAllStandardShapes } from "../domain/standardShapeLibrary";
import { useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent } from "react";
import { CluePanel } from "../components/CluePanel";
import { WordLookupDialog } from "../components/WordLookupDialog";
import { MetadataPanel } from "../components/MetadataPanel";
import { PuzzleGrid, type PuzzleGridHandle } from "../components/PuzzleGrid";
import { Toolbar } from "../components/Toolbar";
import { ShapePalette } from "../components/ShapePalette";
import { ShapeDesignerSurface } from "../components/ShapeDesignerSurface";
import {
  createInitialShapeDesignerState,
  moveSelection,
  placePrimitiveAtSelection,
  clearPrimitiveAtSelection,
  replaceDesignerLayout,
  resizeDesignerLayout,
} from "../domain/shapeDesignerState";
import type {
  ComposedShapeDefinition,
  ShapePrimitive,
} from "../domain/shapeDefinition";
import {
  buildEmptyContent,
  buildTopology,
  isTopologyReflectableAcrossLeadingDiagonal,
} from "../domain/squareTopology";
import {
  findMatchingWords,
  parseWordListText,
  type LoadedWordList,
} from "../domain/wordList";
import {
  autofillFormModel,
  autofillGrid,
  type AutofillProgress,
} from "../domain/autofill";
import {
  applyWordToDisplayEntryByCell,
  buildCellFillsFromFormFillState,
  buildEmptyFormFillState,
  buildFormFillStateFromCellFills,
  buildFormModelFromTopology,
  formModelRoundTripMatchesCellFills,
  getDisplayEntryPatternById,
  setDisplayedCellCharacter,
} from "../domain/formModel";
import type { DisplayEntry, FormModel } from "../domain/formModel";
import type {
  AppMode,
  EntryDirection,
  EntryRef,
  FormStyle,
  SavedPuzzle,
  ShapeVariant,
  Topology,
} from "../domain/types";
import { buildComposedShapeDefinitionFromDesignerState } from "../domain/shapeSerialization";
import { parseSerializedLayout } from "../domain/shapeLayout";
import { buildPuzzleSpecFromComposedShapeDefinition } from "../domain/shapeInstantiation";
import {
  applyVariantSelection,
  supportsInversion,
  supportsLeftRightVariant,
  type ShapeOrientation,
} from "../domain/shapeTransforms";
import {
  downloadPuzzleFile,
  downloadSolverPuzzleFile,
  readPuzzleFile,
} from "../io/puzzleFile";
import {
  downloadShapeDefinitionFile,
  readShapeDefinitionFile,
} from "../io/shapeFile";
import {
  createInitialPuzzleStore,
  getEntryForCell,
  toggleDirectionForRepeatedCellClick,
} from "../state/puzzleStore";
import "../styles/app.css";

const WORD_LOOKUP_PAGE_SIZE = 100;

function getCellById(topology: Topology, cellId: string | null) {
  if (!cellId) {
    return undefined;
  }
  return topology.cells.find((cell) => cell.id === cellId);
}

function getEntryIndex(
  entries: EntryRef[],
  entryId: string | undefined,
): number {
  if (!entryId) {
    return -1;
  }
  return entries.findIndex((entry) => entry.id === entryId);
}

function getWrappedEntry(
  entries: EntryRef[],
  currentIndex: number,
  step: 1 | -1,
): EntryRef | undefined {
  if (entries.length === 0 || currentIndex < 0) {
    return undefined;
  }

  const nextIndex = (currentIndex + step + entries.length) % entries.length;
  return entries[nextIndex];
}

function getNextCellIdInEntry(
  entry: EntryRef | undefined,
  currentCellId: string | null,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  return (
    entry.cells[Math.min(index + 1, entry.cells.length - 1)] ?? currentCellId
  );
}

function getPreviousCellIdInEntry(
  entry: EntryRef | undefined,
  currentCellId: string | null,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  return entry.cells[Math.max(index - 1, 0)] ?? currentCellId;
}

function getNextSolveCellId(
  entry: EntryRef | undefined,
  currentCellId: string | null,
  fillsByCellIdBefore: Record<string, string>,
): string | null {
  if (!entry || !currentCellId) {
    return currentCellId;
  }

  const index = entry.cells.indexOf(currentCellId);
  if (index < 0) {
    return currentCellId;
  }

  const currentWasBlank = (fillsByCellIdBefore[currentCellId] ?? "") === "";

  if (!currentWasBlank) {
    return (
      entry.cells[Math.min(index + 1, entry.cells.length - 1)] ?? currentCellId
    );
  }

  for (let i = index + 1; i < entry.cells.length; i += 1) {
    const cellId = entry.cells[i];
    if ((fillsByCellIdBefore[cellId] ?? "") === "") {
      return cellId;
    }
  }

  for (let i = index + 1; i < entry.cells.length; i += 1) {
    const cellId = entry.cells[i];
    if ((fillsByCellIdBefore[cellId] ?? "") !== "") {
      return cellId;
    }
  }

  return currentCellId;
}

function compareCellsReadingOrder(
  left: { row: number; col: number },
  right: { row: number; col: number },
): number {
  if (left.row !== right.row) {
    return left.row - right.row;
  }

  return left.col - right.col;
}

function buildCellById(
  topology: Topology,
): Map<string, Topology["cells"][number]> {
  return new Map(topology.cells.map((cell) => [cell.id, cell]));
}

function buildDoublePresentationNumbering(topology: Topology): {
  numberByEntryId: Record<string, number>;
  clueNumberByCellId: Record<string, string>;
} {
  const cellById = buildCellById(topology);
  const numberByEntryId: Record<string, number> = {};
  const clueNumberByCellId: Record<string, string> = {};

  const acrossStarts = new Map<string, EntryRef>();
  const downStarts = new Map<string, EntryRef>();

  for (const entry of topology.entries) {
    const startCellId = entry.cells[0];
    if (!startCellId) {
      continue;
    }

    if (entry.direction === "across") {
      acrossStarts.set(startCellId, entry);
    } else {
      downStarts.set(startCellId, entry);
    }
  }

  const startCellIds = [
    ...new Set([...acrossStarts.keys(), ...downStarts.keys()]),
  ];

  startCellIds.sort((leftId, rightId) => {
    const left = cellById.get(leftId);
    const right = cellById.get(rightId);

    if (!left || !right) {
      return 0;
    }

    return compareCellsReadingOrder(left, right);
  });

  let nextAcross = 1;
  let nextDown = 1;

  for (const startCellId of startCellIds) {
    const acrossEntry = acrossStarts.get(startCellId);
    const downEntry = downStarts.get(startCellId);

    if (acrossEntry && downEntry) {
      const number = Math.min(nextAcross, nextDown);
      numberByEntryId[acrossEntry.id] = number;
      numberByEntryId[downEntry.id] = number;
      clueNumberByCellId[startCellId] = String(number);
      nextAcross = number + 1;
      nextDown = number + 1;
      continue;
    }

    if (acrossEntry) {
      numberByEntryId[acrossEntry.id] = nextAcross;
      clueNumberByCellId[startCellId] = String(nextAcross);
      nextAcross += 1;
      continue;
    }

    if (downEntry) {
      numberByEntryId[downEntry.id] = nextDown;
      clueNumberByCellId[startCellId] = String(nextDown);
      nextDown += 1;
    }
  }

  return {
    numberByEntryId,
    clueNumberByCellId,
  };
}

function buildSinglePresentationNumbering(
  formModel: FormModel,
  topology: Topology,
): {
  numberByEntryId: Record<string, number>;
  clueNumberByCellId: Record<string, string>;
  representativeEntryIds: string[];
  representativeEntryIdByFormWordId: Record<string, string>;
} {
  const cellById = buildCellById(topology);
  const grouped = new Map<string, DisplayEntry[]>();

  for (const entry of formModel.displayEntries) {
    const entries = grouped.get(entry.formWordId) ?? [];
    entries.push(entry);
    grouped.set(entry.formWordId, entries);
  }

  const groups = [...grouped.entries()].map(([formWordId, entries]) => {
    const sortedEntries = [...entries].sort((left, right) => {
      const leftCell = cellById.get(left.cellIds[0] ?? "");
      const rightCell = cellById.get(right.cellIds[0] ?? "");

      if (!leftCell || !rightCell) {
        return 0;
      }

      return compareCellsReadingOrder(leftCell, rightCell);
    });

    return {
      formWordId,
      entries: sortedEntries,
      representative: sortedEntries[0],
    };
  });

  groups.sort((left, right) => {
    const leftCell = cellById.get(left.representative.cellIds[0] ?? "");
    const rightCell = cellById.get(right.representative.cellIds[0] ?? "");

    if (!leftCell || !rightCell) {
      return 0;
    }

    return compareCellsReadingOrder(leftCell, rightCell);
  });

  const numberByEntryId: Record<string, number> = {};
  const clueNumberByCellId: Record<string, string> = {};
  const representativeEntryIds: string[] = [];
  const representativeEntryIdByFormWordId: Record<string, string> = {};

  groups.forEach((group, index) => {
    const number = index + 1;
    representativeEntryIds.push(group.representative.id);
    representativeEntryIdByFormWordId[group.formWordId] =
      group.representative.id;

    for (const entry of group.entries) {
      numberByEntryId[entry.id] = number;
      const startCellId = entry.cellIds[0];
      if (startCellId) {
        clueNumberByCellId[startCellId] = String(number);
      }
    }
  });

  return {
    numberByEntryId,
    clueNumberByCellId,
    representativeEntryIds,
    representativeEntryIdByFormWordId,
  };
}

function relabelEntry(
  entry: EntryRef,
  number: number,
  single: boolean,
): EntryRef {
  return {
    ...entry,
    number,
    label: single
      ? String(number)
      : `${number}${entry.direction === "across" ? "A" : "D"}`,
  };
}

function getFormTypeTitle(
  shapeVariant: ShapeVariant,
  formStyle: FormStyle,
  inverted: boolean,
  shapeName?: string,
): string {
  const parts: string[] = [];

  if (formStyle === "double") {
    parts.push("Double");
  }

  if (inverted) {
    parts.push("Inverted");
  }

  if (shapeVariant === "left") {
    parts.push("Left");
  } else if (shapeVariant === "right") {
    parts.push("Right");
  }

  parts.push(shapeName?.trim() || "Composed Shape");
  return parts.join(" ");
}

function getAllowedSizes(): number[] {
  return [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
}

function resolveFormStyleForTopology(
  requestedFormStyle: FormStyle,
  topology: Topology,
): FormStyle {
  if (requestedFormStyle === "single") {
    return isTopologyReflectableAcrossLeadingDiagonal(topology)
      ? "single"
      : "double";
  }

  return "double";
}

function buildSavedPuzzle(
  store: ReturnType<typeof createInitialPuzzleStore>,
): SavedPuzzle {
  return {
    version: 1,
    spec: store.spec,
    topology: store.topology,
    content: store.content,
    state: store.state,
    solution: store.solution,
  };
}

export default function App() {
  const [store, setStore] = useState(() => createInitialPuzzleStore(5));
  const gridRef = useRef<PuzzleGridHandle | null>(null);
  const [isDirty, setIsDirty] = useState(false);
  const [loadedWordList, setLoadedWordList] = useState<LoadedWordList | null>(
    null,
  );
  const [loadedPuzzleFileName, setLoadedPuzzleFileName] = useState<
    string | null
  >(null);
  const [loadedWordListName, setLoadedWordListName] = useState<string | null>(
    null,
  );
  const [lockCompletedWords, setLockCompletedWords] = useState(true);
  const [randomizeAutofillChoices, setRandomizeAutofillChoices] =
    useState(true);
  const [isAutofillRunning, setIsAutofillRunning] = useState(false);
  const [autofillStatusText, setAutofillStatusText] =
    useState("Autofill idle.");
  const [uiStatusText, setUiStatusText] = useState("Ready.");
  const [uiStatusKind, setUiStatusKind] = useState<
    "info" | "success" | "error"
  >("info");
  const autofillShouldContinueRef = useRef(true);
  const [isWordLookupOpen, setIsWordLookupOpen] = useState(false);
  const [wordLookupMatches, setWordLookupMatches] = useState<string[]>([]);
  const [wordLookupTotal, setWordLookupTotal] = useState(0);
  const [wordLookupOffset, setWordLookupOffset] = useState(0);
  const [shapeDesignerState, setShapeDesignerState] = useState(
    createInitialShapeDesignerState(),
  );
  const [sessionShapeLibrary, setSessionShapeLibrary] = useState<
    ComposedShapeDefinition[]
  >(() => getAllStandardShapes());
  const [selectedLibraryShapeId, setSelectedLibraryShapeId] = useState<
    string | null
  >(null);
  const loadShapeFileInputRef = useRef<HTMLInputElement | null>(null);
  const isConstruct = store.mode === "construct";
  const isDesigner = store.mode === "designer";
  const isSolveStrict = store.mode === "solve_strict";
  const isSolveCheckable = store.mode === "solve_checkable";
  const isSolve = isSolveStrict || isSolveCheckable;
  const currentShapeVariant: ShapeVariant = store.spec.shapeVariant ?? "left";
  const currentFormStyle: FormStyle = store.spec.formStyle ?? "double";
  const currentInverted = store.spec.inverted ?? false;

  const canBeSingle = useMemo(() => {
    return isTopologyReflectableAcrossLeadingDiagonal(store.topology);
  }, [store.topology]);

  const formTypeTitle = getFormTypeTitle(
    currentShapeVariant,
    currentFormStyle,
    currentInverted,
    store.spec.shapeName,
  );

  const allowedSizes = getAllowedSizes();

  const currentComposedLayout = useMemo(() => {
    if (store.spec.shapeFamily !== "composed" || !store.spec.composedLayout) {
      return null;
    }

    const parsed = parseSerializedLayout(store.spec.composedLayout);
    parsed.overlapRows = store.spec.overlapRows ?? 1;
    parsed.overlapCols = store.spec.overlapCols ?? 1;
    return parsed;
  }, [
    store.spec.shapeFamily,
    store.spec.composedLayout,
    store.spec.overlapRows,
    store.spec.overlapCols,
  ]);

  const selectedLibraryShape = useMemo(
    () =>
      sessionShapeLibrary.find((item) => item.id === selectedLibraryShapeId) ??
      null,
    [sessionShapeLibrary, selectedLibraryShapeId],
  );

  const currentCanonicalLibraryShape = useMemo(() => {
    if (store.spec.shapeId) {
      const byId = sessionShapeLibrary.find(
        (item) => item.id === store.spec.shapeId,
      );
      if (byId) {
        return byId;
      }
    }

    return selectedLibraryShape ?? null;
  }, [sessionShapeLibrary, store.spec.shapeId, selectedLibraryShape]);

  const currentShapeSupportsLeftRight = useMemo(() => {
    if (currentCanonicalLibraryShape) {
      return supportsLeftRightVariant(currentCanonicalLibraryShape.layout);
    }

    if (!currentComposedLayout) {
      return false;
    }

    return supportsLeftRightVariant(currentComposedLayout);
  }, [currentCanonicalLibraryShape, currentComposedLayout]);

  const currentShapeSupportsInversion = useMemo(() => {
    if (currentCanonicalLibraryShape) {
      return supportsInversion(currentCanonicalLibraryShape.layout);
    }

    if (!currentComposedLayout) {
      return false;
    }

    return supportsInversion(currentComposedLayout);
  }, [currentCanonicalLibraryShape, currentComposedLayout]);

  const activeShapeDefinition = useMemo(() => {
    return currentCanonicalLibraryShape ?? selectedLibraryShape ?? null;
  }, [currentCanonicalLibraryShape, selectedLibraryShape]);

  const showAutofillBanner =
    isAutofillRunning ||
    autofillStatusText.startsWith("Autofill running") ||
    autofillStatusText.startsWith("Stopping autofill");

  useEffect(() => {
    function handleBeforeUnload(event: BeforeUnloadEvent) {
      if (!isDirty) {
        return;
      }

      event.preventDefault();
      event.returnValue = "";
    }

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isDirty]);

  function confirmDiscardChanges(actionDescription: string): boolean {
    if (!isDirty) {
      return true;
    }

    return window.confirm(
      `You have unsaved changes. Discard them and ${actionDescription}?`,
    );
  }

  function setUiStatus(
    text: string,
    kind: "info" | "success" | "error" = "info",
  ) {
    setUiStatusText(text);
    setUiStatusKind(kind);
  }

  const activeEntry = useMemo(() => {
    if (!store.selection.cellId) {
      return undefined;
    }

    return getEntryForCell(
      store.topology,
      store.selection.cellId,
      store.selection.direction,
    );
  }, [store.selection, store.topology]);

  const acrossEntries = useMemo(
    () =>
      store.topology.entries.filter((entry) => entry.direction === "across"),
    [store.topology.entries],
  );

  const downEntries = useMemo(
    () => store.topology.entries.filter((entry) => entry.direction === "down"),
    [store.topology.entries],
  );

  const formModel = useMemo(() => {
    return buildFormModelFromTopology(store.spec, store.topology);
  }, [store.spec, store.topology]);

  const formFillState = store.state;

  const presentationNumbering = useMemo(() => {
    return currentFormStyle === "single"
      ? buildSinglePresentationNumbering(formModel, store.topology)
      : buildDoublePresentationNumbering(store.topology);
  }, [currentFormStyle, formModel, store.topology]);

  const cluesByEntryId = useMemo(() => {
    const clueTextByFormWordId = Object.fromEntries(
      store.content.clues.map((clue) => [clue.formWordId, clue.text]),
    ) as Record<string, string>;

    return Object.fromEntries(
      formModel.displayEntries.map((entry) => [
        entry.id,
        clueTextByFormWordId[entry.formWordId] ?? "",
      ]),
    ) as Record<string, string>;
  }, [formModel.displayEntries, store.content.clues]);

  const displayedAcrossEntries = useMemo(() => {
    if (currentFormStyle === "single") {
      return [];
    }

    return acrossEntries.map((entry) =>
      relabelEntry(
        entry,
        presentationNumbering.numberByEntryId[entry.id] ?? entry.number,
        false,
      ),
    );
  }, [acrossEntries, currentFormStyle, presentationNumbering.numberByEntryId]);

  const displayedDownEntries = useMemo(() => {
    if (currentFormStyle === "single") {
      return [];
    }

    return downEntries.map((entry) =>
      relabelEntry(
        entry,
        presentationNumbering.numberByEntryId[entry.id] ?? entry.number,
        false,
      ),
    );
  }, [downEntries, currentFormStyle, presentationNumbering.numberByEntryId]);

  const singleClueEntries = useMemo(() => {
    if (
      currentFormStyle !== "single" ||
      !("representativeEntryIds" in presentationNumbering)
    ) {
      return [];
    }

    const entriesById = new Map(
      store.topology.entries.map((entry) => [entry.id, entry]),
    );

    return presentationNumbering.representativeEntryIds
      .map((entryId) => {
        const entry = entriesById.get(entryId);
        if (!entry) {
          return undefined;
        }

        return relabelEntry(
          entry,
          presentationNumbering.numberByEntryId[entry.id] ?? entry.number,
          true,
        );
      })
      .filter((entry): entry is EntryRef => Boolean(entry));
  }, [currentFormStyle, presentationNumbering, store.topology.entries]);

  const activeEntryPattern = useMemo(() => {
    if (!activeEntry) {
      return "";
    }

    return getDisplayEntryPatternById(formModel, formFillState, activeEntry.id);
  }, [activeEntry, formModel, formFillState]);

  const activeDisplayEntry = useMemo(() => {
    if (!activeEntry) {
      return undefined;
    }

    return formModel.displayEntries.find(
      (entry) => entry.id === activeEntry.id,
    );
  }, [activeEntry, formModel.displayEntries]);

  const activeFormWordId = activeDisplayEntry?.formWordId;

  const activeGridCellIds = useMemo(() => {
    if (!activeEntry) {
      return [];
    }

    if (currentFormStyle !== "single" || !activeFormWordId) {
      return [...activeEntry.cells];
    }

    const groupedCellIds = new Set<string>();

    for (const entry of formModel.displayEntries) {
      if (entry.formWordId !== activeFormWordId) {
        continue;
      }

      for (const cellId of entry.cellIds) {
        groupedCellIds.add(cellId);
      }
    }

    return [...groupedCellIds];
  }, [
    activeEntry,
    activeFormWordId,
    currentFormStyle,
    formModel.displayEntries,
  ]);

  const activeClueEntryId = useMemo(() => {
    if (!activeEntry) {
      return undefined;
    }

    if (
      currentFormStyle !== "single" ||
      !activeFormWordId ||
      !("representativeEntryIdByFormWordId" in presentationNumbering)
    ) {
      return activeEntry.id;
    }

    return presentationNumbering.representativeEntryIdByFormWordId[
      activeFormWordId
    ];
  }, [activeEntry, activeFormWordId, currentFormStyle, presentationNumbering]);

  const projectedFillsByCellId = useMemo(() => {
    return buildCellFillsFromFormFillState(formModel, formFillState);
  }, [formModel, formFillState]);

  const formModelRoundTripOk = useMemo(() => {
    return formModelRoundTripMatchesCellFills(
      formModel,
      projectedFillsByCellId,
    );
  }, [formModel, projectedFillsByCellId]);

  void formModelRoundTripOk;

  function handleCellClick(cellId: string) {
    setStore((prev) => ({
      ...prev,
      selection: toggleDirectionForRepeatedCellClick(
        prev.topology,
        prev.selection,
        cellId,
      ),
    }));
  }

  function selectEntry(entry: EntryRef) {
    setStore((prev) => ({
      ...prev,
      selection: {
        cellId: entry.cells[0] ?? null,
        direction: entry.direction,
      },
    }));
  }

  function handleEntryClick(entryId: string) {
    const entry = store.topology.entries.find((e) => e.id === entryId);
    if (!entry) {
      return;
    }
    selectEntry(entry);
  }

  function moveToAdjacentEntry(step: 1 | -1) {
    if (!activeEntry) {
      return;
    }

    const entries =
      activeEntry.direction === "across" ? acrossEntries : downEntries;
    const index = getEntryIndex(entries, activeEntry.id);
    const nextEntry = getWrappedEntry(entries, index, step);
    if (!nextEntry) {
      return;
    }

    selectEntry(nextEntry);
  }

  function handleClueChange(entryId: string, text: string) {
    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      const currentFormModel = buildFormModelFromTopology(
        prev.spec,
        prev.topology,
      );

      const displayEntry = currentFormModel.displayEntries.find(
        (entry) => entry.id === entryId,
      );
      if (!displayEntry) {
        return prev;
      }

      return {
        ...prev,
        content: {
          ...prev.content,
          clues: prev.content.clues.map((clue) =>
            clue.formWordId === displayEntry.formWordId
              ? { ...clue, text }
              : clue,
          ),
        },
      };
    });

    if (store.mode === "construct") {
      setIsDirty(true);
    }
  }

  function handleSizeChange(size: number) {
    if (!confirmDiscardChanges("change the puzzle size")) {
      return;
    }

    if (!activeShapeDefinition) {
      return;
    }

    instantiateComposedShape(activeShapeDefinition, {
      size,
      orientation: currentShapeVariant === "right" ? "right" : "left",
      inverted: currentShapeSupportsInversion ? currentInverted : false,
      requestedFormStyle: currentFormStyle,
      uiMessage: "Updated puzzle size.",
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleShapeVariantChange(shapeVariant: ShapeVariant) {
    if (shapeVariant === currentShapeVariant) {
      return;
    }

    if (!confirmDiscardChanges("change the puzzle variant")) {
      return;
    }

    if (!activeShapeDefinition) {
      return;
    }

    instantiateComposedShape(activeShapeDefinition, {
      size: store.spec.size,
      orientation: shapeVariant === "right" ? "right" : "left",
      inverted: currentShapeSupportsInversion ? currentInverted : false,
      requestedFormStyle: currentFormStyle,
      uiMessage: `Updated shape variant: ${shapeVariant}.`,
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleInvertedChange(inverted: boolean) {
    if (!currentShapeSupportsInversion || inverted === currentInverted) {
      return;
    }

    if (!confirmDiscardChanges("change the puzzle orientation")) {
      return;
    }

    if (!activeShapeDefinition) {
      return;
    }

    instantiateComposedShape(activeShapeDefinition, {
      size: store.spec.size,
      orientation: currentShapeVariant === "right" ? "right" : "left",
      inverted,
      requestedFormStyle: currentFormStyle,
      uiMessage: "Updated shape inversion.",
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleNewPuzzle(size: number) {
    if (!confirmDiscardChanges("start a new puzzle")) {
      return;
    }

    if (!activeShapeDefinition) {
      return;
    }

    const resolvedSize = allowedSizes.includes(size)
      ? size
      : allowedSizes[allowedSizes.length - 1];

    instantiateComposedShape(activeShapeDefinition, {
      size: resolvedSize,
      orientation: currentShapeVariant === "right" ? "right" : "left",
      inverted: currentShapeSupportsInversion ? currentInverted : false,
      requestedFormStyle: currentFormStyle,
      uiMessage: `Started a new ${activeShapeDefinition.name} puzzle.`,
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleModeChange(mode: AppMode) {
    setStore((prev) => ({ ...prev, mode }));
  }

  function handleDesignerPlacePrimitive(primitive: ShapePrimitive) {
    setShapeDesignerState((prev) => placePrimitiveAtSelection(prev, primitive));
  }

  function instantiateComposedShape(
    definition: ComposedShapeDefinition,
    options?: {
      size?: number;
      orientation?: ShapeOrientation;
      inverted?: boolean;
      requestedFormStyle?: FormStyle;
      uiMessage?: string;
    },
  ) {
    const size = options?.size ?? store.spec.size;
    const orientation = options?.orientation ?? "left";
    const inverted = options?.inverted ?? false;
    const requestedFormStyle = options?.requestedFormStyle ?? currentFormStyle;

    const transformedDefinition: ComposedShapeDefinition = {
      ...definition,
      layout: applyVariantSelection(definition.layout, orientation, inverted),
    };

    const requestedSpec = buildPuzzleSpecFromComposedShapeDefinition(
      transformedDefinition,
      size,
      requestedFormStyle,
    );

    const initialTopology = buildTopology(requestedSpec);
    const resolvedFormStyle = resolveFormStyleForTopology(
      requestedSpec.formStyle ?? "double",
      initialTopology,
    );

    const spec =
      resolvedFormStyle === (requestedSpec.formStyle ?? "double")
        ? {
            ...requestedSpec,
            shapeVariant: orientation === "right" ? "right" : "left",
            inverted,
          }
        : {
            ...requestedSpec,
            formStyle: resolvedFormStyle,
            shapeVariant: orientation === "right" ? "right" : "left",
            inverted,
          };

    const topology =
      resolvedFormStyle === (requestedSpec.formStyle ?? "double")
        ? initialTopology
        : buildTopology(spec);

    const content = buildEmptyContent(spec, topology);

    setSelectedLibraryShapeId(definition.id);

    setStore((prev) => ({
      ...prev,
      spec,
      topology,
      content,
      state: buildEmptyFormFillState(
        buildFormModelFromTopology(spec, topology),
      ),
      selection: {
        cellId: topology.cells[0]?.id ?? null,
        direction: "across",
      },
      mode: "construct",
    }));

    if (options?.uiMessage) {
      setUiStatus(options.uiMessage, "success");
    }
  }

  function upsertSessionShape(definition: ComposedShapeDefinition) {
    setSessionShapeLibrary((prev) => {
      const existingIndex = prev.findIndex((item) => item.id === definition.id);

      if (existingIndex < 0) {
        return [...prev, definition];
      }

      const next = [...prev];
      next[existingIndex] = definition;
      return next;
    });

    setSelectedLibraryShapeId(definition.id);
  }

  function handleUseDesignedShape() {
    try {
      const definition =
        buildComposedShapeDefinitionFromDesignerState(shapeDesignerState);

      upsertSessionShape(definition);

      instantiateComposedShape(definition, {
        size: shapeDesignerState.size,
        orientation: "left",
        inverted: false,
        requestedFormStyle: "single",
        uiMessage: "Constructing from designed shape",
      });
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to use designed shape.";
      window.alert(message);
    }
  }

  function handleSaveDesignedShape() {
    try {
      const definition =
        buildComposedShapeDefinitionFromDesignerState(shapeDesignerState);
      upsertSessionShape(definition);
      downloadShapeDefinitionFile(definition);
      setUiStatus(`Saved shape: ${definition.name}`, "success");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save shape.";
      window.alert(message);
    }
  }

  async function handleLoadDesignedShape(file: File) {
    try {
      const definition = await readShapeDefinitionFile(file);

      if (definition.kind !== "composed") {
        throw new Error("Only composed shapes can be loaded in Designer mode.");
      }

      setShapeDesignerState((prev) =>
        replaceDesignerLayout(prev, definition.layout, definition.name),
      );
      upsertSessionShape(definition);
      setStore((prev) => ({ ...prev, mode: "designer" }));
      setUiStatus(`Loaded shape: ${definition.name}`, "success");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load shape.";
      window.alert(message);
    }
  }

  function handleFormStyleChange(formStyle: FormStyle) {
    if (formStyle === currentFormStyle) {
      return;
    }

    if (formStyle === "single" && !canBeSingle) {
      return;
    }

    if (!confirmDiscardChanges("change the form style")) {
      return;
    }

    if (!activeShapeDefinition) {
      return;
    }

    instantiateComposedShape(activeShapeDefinition, {
      size: store.spec.size,
      orientation: currentShapeVariant === "right" ? "right" : "left",
      inverted: currentShapeSupportsInversion ? currentInverted : false,
      requestedFormStyle: formStyle,
      uiMessage: `Started a new ${formStyle} ${activeShapeDefinition.name} puzzle.`,
    });

    setIsDirty(false);
    setLoadedPuzzleFileName(null);
  }

  function handleCaptureSolution() {
    if (!isConstruct) {
      return;
    }

    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        solution: {
          fillsByFormWordId: { ...prev.state.fillsByFormWordId },
        },
      };
    });

    setIsDirty(true);
    setUiStatus("Solution captured.", "success");
  }

  function handleClearGrid() {
    setStore((prev) => ({
      ...prev,
      state: buildEmptyFormFillState(
        buildFormModelFromTopology(prev.spec, prev.topology),
      ),
    }));

    setIsDirty(true);

    requestAnimationFrame(() => {
      gridRef.current?.focusGrid();
    });
  }

  function handleCheck() {
    if (!store.solution) {
      window.alert("No stored solution yet.");
      return;
    }

    const currentCellFills = buildCellFillsFromFormFillState(
      formModel,
      store.state,
    );
    const solutionCellFills = buildCellFillsFromFormFillState(
      formModel,
      store.solution,
    );

    const mismatches = Object.keys(solutionCellFills).filter((cellId) => {
      return (
        (currentCellFills[cellId] ?? "") !== (solutionCellFills[cellId] ?? "")
      );
    });

    if (mismatches.length === 0) {
      window.alert("Puzzle is correct.");
    } else {
      window.alert(
        `Puzzle is not yet correct. Mismatched cells: ${mismatches.length}`,
      );
    }
  }

  function handleSave() {
    const puzzle = buildSavedPuzzle(store);
    downloadPuzzleFile(puzzle);
    setIsDirty(false);
  }

  function handleExportSolverVersion() {
    if (!store.solution) {
      window.alert("Capture a solution before exporting a solver version.");
      return;
    }

    const solverPuzzle: SavedPuzzle = {
      version: 1,
      spec: store.spec,
      topology: store.topology,
      content: store.content,
      state: buildEmptyFormFillState(
        buildFormModelFromTopology(store.spec, store.topology),
      ),
      solution: store.solution,
    };

    downloadSolverPuzzleFile(solverPuzzle);
  }

  async function handleLoad(file: File) {
    if (!confirmDiscardChanges("load another puzzle")) {
      return;
    }

    try {
      const puzzle = await readPuzzleFile(file);

      setStore((prev) => {
        const loadedMode = prev.mode;
        const loadedFormModel = buildFormModelFromTopology(
          puzzle.spec,
          puzzle.topology,
        );

        return {
          mode: loadedMode,
          spec: puzzle.spec,
          topology: puzzle.topology,
          content: puzzle.content,
          state:
            loadedMode === "construct"
              ? puzzle.state
              : buildEmptyFormFillState(loadedFormModel),
          solution: puzzle.solution,
          selection: {
            cellId: puzzle.topology.cells[0]?.id ?? null,
            direction: "across",
          },
        };
      });

      setLoadedPuzzleFileName(file.name);
      setIsDirty(false);
      setUiStatus(`Loaded puzzle: ${file.name}`, "success");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load puzzle file.";
      window.alert(message);
    }
  }

  async function handleLoadWordList(file: File) {
    try {
      const text = await file.text();
      const parsed = parseWordListText(text, file.name);
      setLoadedWordList(parsed);
      setLoadedWordListName(file.name);

      setUiStatus(
        `Loaded word list: ${parsed.name} (${parsed.eligibleEntries.length.toLocaleString()} eligible entries)`,
        "success",
      );
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to load word list file.";
      window.alert(message);
    }
  }

  function handleFindWords() {
    if (!activeEntry) {
      setUiStatus("No active entry selected.", "info");
      return;
    }

    if (!loadedWordList) {
      setUiStatus("No word list loaded.", "info");
      return;
    }

    if (!activeEntryPattern) {
      setUiStatus("Unable to derive a pattern for the active entry.", "error");
      return;
    }

    const result = findMatchingWords(
      loadedWordList,
      activeEntryPattern,
      0,
      WORD_LOOKUP_PAGE_SIZE,
    );

    if (result.total === 0) {
      setUiStatus(`No matches for pattern ${activeEntryPattern}.`, "info");
      return;
    }

    setWordLookupMatches(result.matches);
    setWordLookupTotal(result.total);
    setWordLookupOffset(result.matches.length);
    setIsWordLookupOpen(true);
    setUiStatus(
      `Found ${result.total.toLocaleString()} matches for pattern ${activeEntryPattern}.`,
      "success",
    );
  }

  async function handleAutofill() {
    if (!loadedWordList) {
      setUiStatus("No word list loaded.", "info");
      return;
    }

    if (isAutofillRunning) {
      return;
    }

    autofillShouldContinueRef.current = true;
    setIsAutofillRunning(true);
    setAutofillStatusText("Autofill running...");
    setUiStatus("Autofill running...", "info");
    await new Promise((resolve) => setTimeout(resolve, 0));

    try {
      if (currentFormStyle === "single") {
        const result = await autofillFormModel(
          formModel,
          store.state,
          loadedWordList,
          {
            lockCompletedWords,
            randomizeChoices: randomizeAutofillChoices,
          },
          {
            shouldContinue: () => autofillShouldContinueRef.current,
            onProgress: (progress: AutofillProgress) => {
              setAutofillStatusText(
                `Autofill running... nodes visited: ${progress.nodesVisited.toLocaleString()}`,
              );

              if (progress.partialFormFillState) {
                setStore((prev) => ({
                  ...prev,
                  state: progress.partialFormFillState!,
                }));
              }
            },
            progressInterval: 1000,
            yieldInterval: 250,
          },
        );

        if (!autofillShouldContinueRef.current) {
          setAutofillStatusText("Autofill cancelled.");
          setUiStatus("Autofill cancelled.", "info");
          return;
        }

        if (!result) {
          setAutofillStatusText("Autofill failed: no solution found.");
          setUiStatus("No autofill solution found.", "error");
          return;
        }

        setStore((prev) => ({
          ...prev,
          state: result,
        }));
      } else {
        const currentCellFills = buildCellFillsFromFormFillState(
          formModel,
          store.state,
        );

        const result = await autofillGrid(
          store.topology,
          currentCellFills,
          loadedWordList,
          {
            lockCompletedWords,
            randomizeChoices: randomizeAutofillChoices,
          },
          {
            shouldContinue: () => autofillShouldContinueRef.current,
            onProgress: (progress: AutofillProgress) => {
              setAutofillStatusText(
                `Autofill running... nodes visited: ${progress.nodesVisited.toLocaleString()}`,
              );

              if (progress.partialGridFillsByCellId) {
                setStore((prev) => {
                  const currentFormModel = buildFormModelFromTopology(
                    prev.spec,
                    prev.topology,
                  );

                  return {
                    ...prev,
                    state: buildFormFillStateFromCellFills(
                      currentFormModel,
                      progress.partialGridFillsByCellId!,
                    ),
                  };
                });
              }
            },
            progressInterval: 100,
            yieldInterval: 250,
          },
        );

        if (!autofillShouldContinueRef.current) {
          setAutofillStatusText("Autofill cancelled.");
          setUiStatus("Autofill cancelled.", "info");
          return;
        }

        if (!result) {
          setAutofillStatusText("Autofill failed: no solution found.");
          setUiStatus("No autofill solution found.", "error");
          return;
        }

        setStore((prev) => {
          const currentFormModel = buildFormModelFromTopology(
            prev.spec,
            prev.topology,
          );

          return {
            ...prev,
            state: buildFormFillStateFromCellFills(currentFormModel, result),
          };
        });
      }
      setIsDirty(true);
      setAutofillStatusText("Autofill succeeded.");
      setUiStatus("Autofill succeeded.", "success");

      requestAnimationFrame(() => {
        gridRef.current?.focusGrid();
      });
    } finally {
      setIsAutofillRunning(false);
    }
  }

  function handleStopAutofill() {
    autofillShouldContinueRef.current = false;
    setAutofillStatusText("Stopping autofill...");
    setUiStatus("Stopping autofill...", "info");
  }

  function handleLoadMoreWordLookupMatches() {
    if (!loadedWordList || !activeEntryPattern) {
      return;
    }

    const result = findMatchingWords(
      loadedWordList,
      activeEntryPattern,
      wordLookupOffset,
      WORD_LOOKUP_PAGE_SIZE,
    );

    setWordLookupMatches((prev) => [...prev, ...result.matches]);
    setWordLookupOffset((prev) => prev + result.matches.length);
  }

  function handleApplyWordLookupWord(word: string) {
    if (!activeEntry) {
      return;
    }

    const nextFormFillState = applyWordToDisplayEntryByCell(
      formModel,
      formFillState,
      activeEntry.id,
      word,
    );

    setStore((prev) => ({
      ...prev,
      state: nextFormFillState,
    }));

    setIsDirty(true);
    setIsWordLookupOpen(false);
    setUiStatus(`Applied word: ${word}`, "success");

    requestAnimationFrame(() => {
      gridRef.current?.focusGrid();
    });
  }

  function handleCloseWordLookup() {
    setIsWordLookupOpen(false);
  }

  function handleTitleChange(title: string) {
    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        content: {
          ...prev.content,
          metadata: {
            ...prev.content.metadata,
            title,
          },
        },
      };
    });

    if (store.mode === "construct") {
      setIsDirty(true);
    }
  }

  function handleAuthorChange(author: string) {
    setStore((prev) => {
      if (prev.mode !== "construct") {
        return prev;
      }

      return {
        ...prev,
        content: {
          ...prev.content,
          metadata: {
            ...prev.content.metadata,
            author,
          },
        },
      };
    });

    if (store.mode === "construct") {
      setIsDirty(true);
    }
  }

  function moveSelectionByArrow(
    direction: EntryDirection,
    deltaRow: number,
    deltaCol: number,
  ) {
    setStore((prev) => {
      const currentCell = getCellById(prev.topology, prev.selection.cellId);
      if (!currentCell) {
        return prev;
      }

      let candidateCells;

      if (deltaCol !== 0) {
        candidateCells = prev.topology.cells
          .filter((cell) => cell.row === currentCell.row)
          .sort((a, b) => a.col - b.col);

        const index = candidateCells.findIndex(
          (cell) => cell.id === currentCell.id,
        );
        if (index < 0 || candidateCells.length === 0) {
          return prev;
        }

        const step = deltaCol > 0 ? 1 : -1;
        const nextIndex =
          (index + step + candidateCells.length) % candidateCells.length;
        const nextCell = candidateCells[nextIndex];

        return {
          ...prev,
          selection: {
            cellId: nextCell.id,
            direction,
          },
        };
      }

      candidateCells = prev.topology.cells
        .filter((cell) => cell.col === currentCell.col)
        .sort((a, b) => a.row - b.row);

      const index = candidateCells.findIndex(
        (cell) => cell.id === currentCell.id,
      );
      if (index < 0 || candidateCells.length === 0) {
        return prev;
      }

      const step = deltaRow > 0 ? 1 : -1;
      const nextIndex =
        (index + step + candidateCells.length) % candidateCells.length;
      const nextCell = candidateCells[nextIndex];

      return {
        ...prev,
        selection: {
          cellId: nextCell.id,
          direction,
        },
      };
    });
  }

  function handleGridKeyDown(event: KeyboardEvent<SVGSVGElement>) {
    const key = event.key;

    if (key === "Tab") {
      event.preventDefault();
      moveToAdjacentEntry(event.shiftKey ? -1 : 1);
      return;
    }

    if (key === "Enter") {
      event.preventDefault();
      moveToAdjacentEntry(1);
      return;
    }

    if (key === "ArrowLeft") {
      event.preventDefault();
      moveSelectionByArrow("across", 0, -1);
      return;
    }

    if (key === "ArrowRight") {
      event.preventDefault();
      moveSelectionByArrow("across", 0, 1);
      return;
    }

    if (key === "ArrowUp") {
      event.preventDefault();
      moveSelectionByArrow("down", -1, 0);
      return;
    }

    if (key === "ArrowDown") {
      event.preventDefault();
      moveSelectionByArrow("down", 1, 0);
      return;
    }

    if (key === "Backspace") {
      event.preventDefault();

      setStore((prev) => {
        if (!prev.selection.cellId) {
          return prev;
        }

        const entry = getEntryForCell(
          prev.topology,
          prev.selection.cellId,
          prev.selection.direction,
        );
        if (!entry) {
          return prev;
        }

        const currentFormModel = buildFormModelFromTopology(
          prev.spec,
          prev.topology,
        );
        const currentFormFillState = prev.state;

        const nextFormFillState = setDisplayedCellCharacter(
          currentFormModel,
          currentFormFillState,
          prev.selection.cellId,
          "",
        );

        return {
          ...prev,
          state: nextFormFillState,
          selection: {
            ...prev.selection,
            cellId: getPreviousCellIdInEntry(entry, prev.selection.cellId),
          },
        };
      });

      setIsDirty(true);
      return;
    }

    if (/^[a-zA-Z]$/.test(key) || key === " ") {
      event.preventDefault();

      const letter = key === " " ? "" : key.toUpperCase();

      setStore((prev) => {
        if (!prev.selection.cellId) {
          return prev;
        }

        const entry = getEntryForCell(
          prev.topology,
          prev.selection.cellId,
          prev.selection.direction,
        );
        if (!entry) {
          return prev;
        }

        const currentFormModel = buildFormModelFromTopology(
          prev.spec,
          prev.topology,
        );
        const fillsBefore = buildCellFillsFromFormFillState(
          currentFormModel,
          prev.state,
        );
        const currentFormFillState = prev.state;

        const nextFormFillState = setDisplayedCellCharacter(
          currentFormModel,
          currentFormFillState,
          prev.selection.cellId,
          letter,
        );

        const nextCellId =
          prev.mode === "solve_strict" || prev.mode === "solve_checkable"
            ? getNextSolveCellId(entry, prev.selection.cellId, fillsBefore)
            : getNextCellIdInEntry(entry, prev.selection.cellId);

        return {
          ...prev,
          state: nextFormFillState,
          selection: {
            ...prev.selection,
            cellId: nextCellId,
          },
        };
      });

      setIsDirty(true);
    }
  }

  function handleClueInputKeyDown(
    event: React.KeyboardEvent<HTMLTextAreaElement>,
    entryId: string,
  ) {
    const topologyEntry = store.topology.entries.find((e) => e.id === entryId);
    if (!topologyEntry) {
      return;
    }

    if (keyIsNavigation(event.key)) {
      return;
    }

    const entries =
      currentFormStyle === "single"
        ? singleClueEntries
        : [...displayedAcrossEntries, ...displayedDownEntries];

    if (event.key === "Tab") {
      event.preventDefault();
      const index = getEntryIndex(entries, entryId);
      const nextEntry = getWrappedEntry(
        entries,
        index,
        event.shiftKey ? -1 : 1,
      );
      if (nextEntry) {
        selectEntry(nextEntry);
      }
      return;
    }

    if (event.key === "Enter") {
      event.preventDefault();
      const index = getEntryIndex(entries, entryId);
      const nextEntry = getWrappedEntry(entries, index, 1);
      if (nextEntry) {
        selectEntry(nextEntry);
      }
    }
  }

  function handleDesignerKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    const key = event.key;

    if (key === "ArrowLeft") {
      event.preventDefault();
      setShapeDesignerState((prev) => ({
        ...prev,
        selection: moveSelection(prev.layout, prev.selection, 0, -1),
      }));
      return;
    }

    if (key === "ArrowRight") {
      event.preventDefault();
      setShapeDesignerState((prev) => ({
        ...prev,
        selection: moveSelection(prev.layout, prev.selection, 0, 1),
      }));
      return;
    }

    if (key === "ArrowUp") {
      event.preventDefault();
      setShapeDesignerState((prev) => ({
        ...prev,
        selection: moveSelection(prev.layout, prev.selection, -1, 0),
      }));
      return;
    }

    if (key === "ArrowDown") {
      event.preventDefault();
      setShapeDesignerState((prev) => ({
        ...prev,
        selection: moveSelection(prev.layout, prev.selection, 1, 0),
      }));
      return;
    }

    if (key === "Backspace") {
      event.preventDefault();
      setShapeDesignerState((prev) => clearPrimitiveAtSelection(prev, true));
      return;
    }

    if (key === " ") {
      event.preventDefault();
      setShapeDesignerState((prev) => clearPrimitiveAtSelection(prev, false));
      return;
    }

    if (key === "Enter") {
      event.preventDefault();
      setShapeDesignerState((prev) => ({
        ...prev,
        selection: {
          row: Math.min(prev.layout.height - 1, prev.selection.row + 1),
          col: 0,
        },
      }));
      return;
    }

    if (
      key === "L" ||
      key === "R" ||
      key === "S" ||
      key === "l" ||
      key === "r"
    ) {
      event.preventDefault();
      handleDesignerPlacePrimitive(key as ShapePrimitive);
      return;
    }
  }

  function keyIsNavigation(key: string): boolean {
    return (
      key === "ArrowLeft" ||
      key === "ArrowRight" ||
      key === "ArrowUp" ||
      key === "ArrowDown"
    );
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>Form Friend{isDirty ? " *" : ""}</h1>
        <div className={`header-status-message header-status-${uiStatusKind}`}>
          {uiStatusText}
        </div>
      </header>

      <main className="app-main">
        <aside className="left-panel">
          <section className="clue-panel">
            <h3>Mode</h3>
            <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
              <button
                type="button"
                onClick={() => handleModeChange("construct")}
              >
                Construct
              </button>
              <button
                type="button"
                onClick={() => handleModeChange("solve_strict")}
              >
                Solve strict
              </button>
              <button
                type="button"
                onClick={() => handleModeChange("solve_checkable")}
              >
                Solve checkable
              </button>
              <button
                type="button"
                onClick={() => handleModeChange("designer")}
              >
                Designer
              </button>
            </div>
          </section>

          {!isDesigner ? (
            <>
              <Toolbar
                size={store.spec.size}
                allowedSizes={allowedSizes}
                shapeVariant={currentShapeVariant}
                formStyle={currentFormStyle}
                inverted={currentInverted}
                canBeSingle={canBeSingle}
                supportsInverted={currentShapeSupportsInversion}
                formTypeTitle={formTypeTitle}
                supportsShapeVariantToggle={currentShapeSupportsLeftRight}
                shapeDisplayName={store.spec.shapeName}
                libraryShapeOptions={sessionShapeLibrary.map((shape) => ({
                  id: shape.id,
                  name: shape.name,
                }))}
                selectedLibraryShapeId={selectedLibraryShapeId}
                onLibraryShapeChange={(shapeId) => {
                  const definition = sessionShapeLibrary.find(
                    (item) => item.id === shapeId,
                  );
                  if (!definition) {
                    return;
                  }

                  instantiateComposedShape(definition, {
                    size: store.spec.size,
                    orientation:
                      supportsLeftRightVariant(definition.layout) &&
                      currentShapeVariant === "right"
                        ? "right"
                        : "left",
                    inverted: supportsInversion(definition.layout)
                      ? currentInverted
                      : false,
                    requestedFormStyle: currentFormStyle,
                    uiMessage: `Using shape: ${definition.name}`,
                  });
                }}
                onShapeVariantChange={handleShapeVariantChange}
                onInvertedChange={handleInvertedChange}
                onFormStyleChange={handleFormStyleChange}
                mode={store.mode}
                isConstruct={isConstruct}
                isSolveStrict={isSolveStrict}
                isSolveCheckable={isSolveCheckable}
                hasSolution={Boolean(store.solution)}
                wordListEntryCount={loadedWordList?.eligibleEntries.length ?? 0}
                loadedPuzzleFileName={loadedPuzzleFileName}
                loadedWordListName={loadedWordListName}
                lockCompletedWords={lockCompletedWords}
                randomizeAutofillChoices={randomizeAutofillChoices}
                isAutofillRunning={isAutofillRunning}
                autofillStatusText={autofillStatusText}
                onNewPuzzle={handleNewPuzzle}
                onSizeChange={handleSizeChange}
                onModeChange={handleModeChange}
                onCaptureSolution={handleCaptureSolution}
                onClearGrid={handleClearGrid}
                onCheck={handleCheck}
                onSave={handleSave}
                onExportSolverVersion={handleExportSolverVersion}
                onLoad={handleLoad}
                onFindWords={handleFindWords}
                onLoadWordList={handleLoadWordList}
                onAutofill={handleAutofill}
                onStopAutofill={handleStopAutofill}
                onLockCompletedWordsChange={setLockCompletedWords}
                onRandomizeAutofillChoicesChange={setRandomizeAutofillChoices}
              />

              <MetadataPanel
                title={store.content.metadata.title}
                author={store.content.metadata.author}
                readOnly={isSolve}
                onTitleChange={handleTitleChange}
                onAuthorChange={handleAuthorChange}
              />
            </>
          ) : (
            <>
              <section className="clue-panel">
                <h3>Designer Settings</h3>
                <label style={{ display: "block", marginBottom: "0.75rem" }}>
                  <span style={{ display: "block", marginBottom: "0.25rem" }}>
                    Shape name
                  </span>
                  <input
                    type="text"
                    value={shapeDesignerState.name}
                    onChange={(e) =>
                      setShapeDesignerState((prev) => ({
                        ...prev,
                        name: e.target.value,
                      }))
                    }
                    style={{ width: "100%" }}
                  />
                </label>

                <label style={{ display: "block", marginBottom: "0.75rem" }}>
                  <span style={{ display: "block", marginBottom: "0.25rem" }}>
                    Primitive size
                  </span>
                  <input
                    type="number"
                    min={2}
                    max={15}
                    value={shapeDesignerState.size}
                    onChange={(e) =>
                      setShapeDesignerState((prev) => ({
                        ...prev,
                        size: Math.max(2, Number(e.target.value) || 2),
                      }))
                    }
                    style={{ width: "100%" }}
                  />
                </label>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: "0.75rem",
                    marginBottom: "0.75rem",
                  }}
                >
                  <label style={{ display: "block" }}>
                    <span style={{ display: "block", marginBottom: "0.25rem" }}>
                      Width
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={12}
                      value={shapeDesignerState.layout.width}
                      onChange={(e) =>
                        setShapeDesignerState((prev) =>
                          resizeDesignerLayout(
                            prev,
                            Math.max(1, Number(e.target.value) || 1),
                            prev.layout.height,
                          ),
                        )
                      }
                      style={{ width: "100%" }}
                    />
                  </label>

                  <label style={{ display: "block" }}>
                    <span style={{ display: "block", marginBottom: "0.25rem" }}>
                      Height
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={12}
                      value={shapeDesignerState.layout.height}
                      onChange={(e) =>
                        setShapeDesignerState((prev) =>
                          resizeDesignerLayout(
                            prev,
                            prev.layout.width,
                            Math.max(1, Number(e.target.value) || 1),
                          ),
                        )
                      }
                      style={{ width: "100%" }}
                    />
                  </label>
                </div>

                <div
                  style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}
                >
                  <button type="button" onClick={handleUseDesignedShape}>
                    Use This Shape
                  </button>
                  <button type="button" onClick={handleSaveDesignedShape}>
                    Save Shape
                  </button>
                  <button
                    type="button"
                    onClick={() => loadShapeFileInputRef.current?.click()}
                  >
                    Load Shape
                  </button>
                </div>

                <input
                  ref={loadShapeFileInputRef}
                  type="file"
                  accept=".json,application/json"
                  style={{ display: "none" }}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) {
                      return;
                    }

                    void handleLoadDesignedShape(file);
                    e.currentTarget.value = "";
                  }}
                />
              </section>
              <ShapePalette
                selectedPrimitive={shapeDesignerState.selectedPrimitive}
                onSelectPrimitive={(primitive) =>
                  setShapeDesignerState((prev) => ({
                    ...prev,
                    selectedPrimitive: primitive,
                  }))
                }
              />
            </>
          )}
        </aside>

        <section className="center-panel">
          {!isDesigner ? (
            <>
              <h3 className="center-title">{formTypeTitle}</h3>
              {showAutofillBanner ? (
                <div
                  style={{
                    display: "block",
                    marginTop: "0.25rem",
                    marginBottom: "0.75rem",
                    fontStyle: "italic",
                    textAlign: "center",
                    fontWeight: 500,
                    minHeight: "1.25rem",
                  }}
                >
                  {autofillStatusText.startsWith("Stopping autofill")
                    ? "Stopping autofill..."
                    : "Autofilling..."}
                </div>
              ) : null}
              <div className="grid-wrapper">
                <PuzzleGrid
                  ref={gridRef}
                  topology={store.topology}
                  fillsByCellId={projectedFillsByCellId}
                  selection={store.selection}
                  activeCellIds={activeGridCellIds}
                  clueNumberByCellId={presentationNumbering.clueNumberByCellId}
                  onCellClick={handleCellClick}
                  onKeyDown={handleGridKeyDown}
                />
              </div>
            </>
          ) : (
            <ShapeDesignerSurface
              layout={shapeDesignerState.layout}
              size={shapeDesignerState.size}
              selection={shapeDesignerState.selection}
              selectedPrimitive={shapeDesignerState.selectedPrimitive}
              onSelectCell={(row, col) =>
                setShapeDesignerState((prev) => ({
                  ...prev,
                  selection: { row, col },
                }))
              }
              onKeyDown={handleDesignerKeyDown}
            />
          )}
        </section>

        <aside
          className="right-panel"
          style={
            isDesigner
              ? { display: "flex", flexDirection: "column", minHeight: 0 }
              : currentFormStyle === "single"
                ? { display: "flex", flexDirection: "column", minHeight: 0 }
                : undefined
          }
        >
          {isDesigner ? (
            <section className="clue-panel" style={{ flex: 1, minHeight: 0 }}>
              <h3>Designer Notes</h3>
              <div className="clue-list" style={{ flex: 1, minHeight: 0 }}>
                <p>
                  This first phase lets you place square and halfsquare
                  primitives on a unified design surface.
                </p>
                <p>Library save/load and constructor handoff come next.</p>
                <p>
                  Current layout:
                  <br />
                  <code>{shapeDesignerState.layout.rows.join(":")}</code>
                </p>
              </div>
            </section>
          ) : currentFormStyle === "single" ? (
            <CluePanel
              title="Clues"
              entries={singleClueEntries}
              cluesByEntryId={cluesByEntryId}
              activeEntryId={activeClueEntryId}
              readOnly={isSolve}
              fillAvailableHeight
              onEntryClick={handleEntryClick}
              onEntryKeyDown={handleClueInputKeyDown}
              onClueChange={handleClueChange}
            />
          ) : (
            <>
              <CluePanel
                title="Across"
                entries={displayedAcrossEntries}
                cluesByEntryId={cluesByEntryId}
                activeEntryId={
                  activeEntry?.direction === "across"
                    ? activeEntry.id
                    : undefined
                }
                readOnly={isSolve}
                onEntryClick={handleEntryClick}
                onEntryKeyDown={handleClueInputKeyDown}
                onClueChange={handleClueChange}
              />

              <CluePanel
                title="Down"
                entries={displayedDownEntries}
                cluesByEntryId={cluesByEntryId}
                activeEntryId={
                  activeEntry?.direction === "down" ? activeEntry.id : undefined
                }
                readOnly={isSolve}
                onEntryClick={handleEntryClick}
                onEntryKeyDown={handleClueInputKeyDown}
                onClueChange={handleClueChange}
              />
            </>
          )}
        </aside>
      </main>
      <WordLookupDialog
        isOpen={isWordLookupOpen}
        pattern={activeEntryPattern}
        totalMatches={wordLookupTotal}
        matches={wordLookupMatches}
        canLoadMore={wordLookupMatches.length < wordLookupTotal}
        onApply={handleApplyWordLookupWord}
        onLoadMore={handleLoadMoreWordLookupMatches}
        onClose={handleCloseWordLookup}
      />
    </div>
  );
}
