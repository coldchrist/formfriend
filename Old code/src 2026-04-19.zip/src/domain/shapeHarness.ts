import type { ComposedShapeDefinition } from "./shapeDefinition";
import { parseSerializedLayout } from "./shapeLayout";
import {
  buildOccupiedCellsFromComposedLayout,
  getOccupiedCellBounds,
} from "./shapeComposition";
import { buildTopologyFromComposedShapeDefinition } from "./shapeTopology";
import { isTopologyReflectableAcrossLeadingDiagonal } from "./squareTopology";

function makeDefinition(
  id: string,
  name: string,
  serializedLayout: string,
): ComposedShapeDefinition {
  return {
    kind: "composed",
    id,
    name,
    layout: parseSerializedLayout(serializedLayout),
  };
}

function renderOccupiedCellsAscii(
  serializedLayout: string,
  size: number,
): string {
  const layout = parseSerializedLayout(serializedLayout);
  const occupied = buildOccupiedCellsFromComposedLayout(layout, size);
  const bounds = getOccupiedCellBounds(occupied);

  if (!bounds) {
    return "(empty)";
  }

  const occupiedSet = new Set(
    occupied.map((cell) => `${cell.row},${cell.col}`),
  );
  const lines: string[] = [];

  for (let row = bounds.minRow; row <= bounds.maxRow; row += 1) {
    let line = "";
    for (let col = bounds.minCol; col <= bounds.maxCol; col += 1) {
      line += occupiedSet.has(`${row},${col}`) ? "#" : ".";
    }
    lines.push(line);
  }

  return lines.join("\n");
}

function summarizeDefinition(
  definition: ComposedShapeDefinition,
  size: number,
): void {
  const occupied = buildOccupiedCellsFromComposedLayout(
    definition.layout,
    size,
  );
  const bounds = getOccupiedCellBounds(occupied);
  const topology = buildTopologyFromComposedShapeDefinition(definition, size);

  console.group(`Shape harness: ${definition.name} @ size ${size}`);
  console.log("layout rows:", definition.layout.rows);
  console.log("serialized layout:", definition.layout.rows.join(":"));
  console.log("occupied cells:", occupied.length);
  console.log("bounds:", bounds);
  console.log(
    "ascii preview:\n" +
      renderOccupiedCellsAscii(definition.layout.rows.join(":"), size),
  );
  console.log(
    "entries:",
    topology.entries.map((entry) => ({
      id: entry.id,
      label: entry.label,
      direction: entry.direction,
      length: entry.cells.length,
      cells: entry.cells,
    })),
  );
  console.log(
    "reflectable across leading diagonal:",
    isTopologyReflectableAcrossLeadingDiagonal(topology),
  );
  console.groupEnd();
}

export function runShapeHarness(): void {
  const cases: Array<{
    id: string;
    name: string;
    layout: string;
    size: number;
  }> = [
    { id: "pyramid", name: "Pyramid candidate", layout: "LR", size: 4 },
    {
      id: "inverted-pyramid",
      name: "Inverted pyramid candidate",
      layout: "lr",
      size: 4,
    },
    { id: "diamond", name: "Diamond candidate", layout: "LR:lr", size: 4 },
  ];

  for (const testCase of cases) {
    const definition = makeDefinition(
      testCase.id,
      testCase.name,
      testCase.layout,
    );
    summarizeDefinition(definition, testCase.size);
  }
}
