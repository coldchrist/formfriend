import { buildFormModelFromTopology } from "./formModel";
import type {
  Cell,
  Clue,
  EntryDirection,
  EntryRef,
  PuzzleContent,
  PuzzleSpec,
  Topology,
  ShapeVariant,
} from "./types";

function cellId(row: number, col: number): string {
  return `r${row}c${col}`;
}

function sortCellsReadingOrder(cells: Cell[]): Cell[] {
  return [...cells].sort((a, b) => {
    if (a.row !== b.row) {
      return a.row - b.row;
    }
    return a.col - b.col;
  });
}

function buildEntriesFromCells(cells: Cell[]): EntryRef[] {
  const sortedCells = sortCellsReadingOrder(cells);
  const cellSet = new Set(cells.map((cell) => cell.id));
  const numberingByCellId = new Map<string, number>();
  let nextNumber = 1;

  function hasCell(row: number, col: number): boolean {
    return cellSet.has(cellId(row, col));
  }

  function isAcrossStart(cell: Cell): boolean {
    return !hasCell(cell.row, cell.col - 1);
  }

  function isDownStart(cell: Cell): boolean {
    return !hasCell(cell.row - 1, cell.col);
  }

  for (const cell of sortedCells) {
    if (isAcrossStart(cell) || isDownStart(cell)) {
      numberingByCellId.set(cell.id, nextNumber);
      nextNumber += 1;
    }
  }

  function buildEntryCells(
    startCell: Cell,
    direction: EntryDirection,
  ): string[] {
    const cellsInEntry: string[] = [];
    let row = startCell.row;
    let col = startCell.col;

    while (hasCell(row, col)) {
      cellsInEntry.push(cellId(row, col));
      if (direction === "across") {
        col += 1;
      } else {
        row += 1;
      }
    }

    return cellsInEntry;
  }

  const acrossEntries: EntryRef[] = [];
  const downEntries: EntryRef[] = [];

  for (const cell of sortedCells) {
    if (isAcrossStart(cell)) {
      const number = numberingByCellId.get(cell.id);
      if (number === undefined) {
        throw new Error(`Missing clue number for cell ${cell.id}`);
      }

      acrossEntries.push({
        id: `A${number}`,
        number,
        label: `${number}A`,
        direction: "across",
        cells: buildEntryCells(cell, "across"),
      });
    }

    if (isDownStart(cell)) {
      const number = numberingByCellId.get(cell.id);
      if (number === undefined) {
        throw new Error(`Missing clue number for cell ${cell.id}`);
      }

      downEntries.push({
        id: `D${number}`,
        number,
        label: `${number}D`,
        direction: "down",
        cells: buildEntryCells(cell, "down"),
      });
    }
  }

  return [...acrossEntries, ...downEntries];
}

function reflectCoordAcrossLeadingDiagonal(row: number, col: number) {
  return { row: col, col: row };
}

export function isTopologyReflectableAcrossLeadingDiagonal(
  topology: Topology,
): boolean {
  const cellSet = new Set(
    topology.cells.map((cell) => `${cell.row},${cell.col}`),
  );

  for (const cell of topology.cells) {
    const reflected = reflectCoordAcrossLeadingDiagonal(cell.row, cell.col);
    if (!cellSet.has(`${reflected.row},${reflected.col}`)) {
      return false;
    }
  }

  return true;
}

export function buildWindmillTopology(spec: PuzzleSpec): Topology {
  if (spec.shapeFamily !== "windmill") {
    throw new Error(
      `Unsupported shape family for windmill builder: ${spec.shapeFamily}`,
    );
  }

  const { size } = spec;
  const variant: ShapeVariant = spec.shapeVariant ?? "left";

  if (!Number.isInteger(size) || size < 2) {
    throw new Error(`Invalid windmill size: ${size}`);
  }

  if (variant !== "left" && variant !== "right") {
    throw new Error(`Unsupported windmill variant: ${variant}`);
  }

  const cells: Cell[] = [];
  const seen = new Set<string>();

  function addCell(row: number, col: number) {
    const id = cellId(row, col);
    if (seen.has(id)) {
      return;
    }
    seen.add(id);
    cells.push({ id, row, col });
  }

  if (variant === "left") {
    // Upper-left square
    for (let row = 0; row < size; row += 1) {
      for (let col = 0; col < size; col += 1) {
        addCell(row, col);
      }
    }

    // Lower-right square, overlapping at one corner cell:
    // bottom-right of the first square === top-left of the second square
    for (let row = size - 1; row < size - 1 + size; row += 1) {
      for (let col = size - 1; col < size - 1 + size; col += 1) {
        addCell(row, col);
      }
    }
  } else {
    // Upper-right square
    for (let row = 0; row < size; row += 1) {
      for (let col = size - 1; col < size - 1 + size; col += 1) {
        addCell(row, col);
      }
    }

    // Lower-left square, overlapping at one corner cell:
    // bottom-left of the first square === top-right of the second square
    for (let row = size - 1; row < size - 1 + size; row += 1) {
      for (let col = 0; col < size; col += 1) {
        addCell(row, col);
      }
    }
  }

  return {
    cells: sortCellsReadingOrder(cells),
    entries: buildEntriesFromCells(cells),
  };
}

export function buildHalfSquareTopology(spec: PuzzleSpec): Topology {
  if (spec.shapeFamily !== "halfsquare") {
    throw new Error(
      `Unsupported shape family for halfsquare builder: ${spec.shapeFamily}`,
    );
  }

  const { size } = spec;
  const variant: ShapeVariant = spec.shapeVariant ?? "left";
  const inverted = spec.inverted ?? false;

  if (!Number.isInteger(size) || size < 2) {
    throw new Error(`Invalid halfsquare size: ${size}`);
  }

  if (variant !== "left" && variant !== "right") {
    throw new Error(`Unsupported halfsquare variant: ${variant}`);
  }

  const cells: Cell[] = [];

  function includeCell(row: number, col: number): boolean {
    if (!inverted) {
      if (variant === "left") {
        return col <= row;
      }

      return col >= size - 1 - row;
    }

    if (variant === "left") {
      return col <= size - 1 - row;
    }

    return col >= row;
  }

  for (let row = 0; row < size; row += 1) {
    for (let col = 0; col < size; col += 1) {
      if (includeCell(row, col)) {
        cells.push({ id: cellId(row, col), row, col });
      }
    }
  }

  return {
    cells: sortCellsReadingOrder(cells),
    entries: buildEntriesFromCells(cells),
  };
}

export function buildSquareTopology(spec: PuzzleSpec): Topology {
  if (spec.shapeFamily !== "square") {
    throw new Error(
      `Unsupported shape family for square builder: ${spec.shapeFamily}`,
    );
  }

  const { size } = spec;

  if (!Number.isInteger(size) || size < 2) {
    throw new Error(`Invalid square size: ${size}`);
  }

  const cells: Cell[] = [];

  for (let row = 0; row < size; row += 1) {
    for (let col = 0; col < size; col += 1) {
      cells.push({ id: cellId(row, col), row, col });
    }
  }

  return {
    cells,
    entries: buildEntriesFromCells(cells),
  };
}

export function buildTopology(spec: PuzzleSpec): Topology {
  switch (spec.shapeFamily) {
    case "square":
      return buildSquareTopology(spec);
    case "windmill":
      return buildWindmillTopology(spec);
    case "halfsquare":
      return buildHalfSquareTopology(spec);
    default:
      throw new Error(`Unsupported shape family: ${spec.shapeFamily}`);
  }
}

export function buildEmptyContent(
  spec: PuzzleSpec,
  topology: Topology,
): PuzzleContent {
  const formModel = buildFormModelFromTopology(spec, topology);

  const clues: Clue[] = formModel.formWords.map((formWord) => ({
    formWordId: formWord.id,
    text: "",
  }));

  return {
    metadata: {
      title: "",
      author: "",
    },
    clues,
  };
}

export function buildEmptyFills(topology: Topology): Record<string, string> {
  const fillsByCellId: Record<string, string> = {};

  for (const cell of topology.cells) {
    fillsByCellId[cell.id] = "";
  }

  return fillsByCellId;
}
