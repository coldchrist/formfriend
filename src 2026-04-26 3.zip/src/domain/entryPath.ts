import type { Cell } from "./types";

export type GridDirection =
  | "east"
  | "south"
  | "southeast"
  | "northeast"
  | "southwest"
  | "northwest"
  | "west"
  | "north";

export interface CellCoord {
  row: number;
  col: number;
}

export interface EntryLine {
  kind: "line";
  start: CellCoord;
  direction: GridDirection;
  length: number;
}

export type EntryPath =
  | {
      kind: "line";
      id: string;
      label?: string;
      segment: EntryLine;
    }
  | {
      kind: "polyline";
      id: string;
      label?: string;
      segments: EntryLine[];
    };

const DIRECTION_STEPS: Record<GridDirection, { row: number; col: number }> = {
  east: { row: 0, col: 1 },
  south: { row: 1, col: 0 },
  southeast: { row: 1, col: 1 },
  northeast: { row: -1, col: 1 },
  southwest: { row: 1, col: -1 },
  northwest: { row: -1, col: -1 },
  west: { row: 0, col: -1 },
  north: { row: -1, col: 0 },
};

function coordKey(coord: CellCoord): string {
  return `${coord.row},${coord.col}`;
}

export function cellIdFromCoord(coord: CellCoord): string {
  return `r${coord.row}c${coord.col}`;
}

function coordFromCellId(cellId: string): CellCoord | null {
  const match = /^r(-?\d+)c(-?\d+)$/.exec(cellId);
  if (!match) {
    return null;
  }

  return {
    row: Number(match[1]),
    col: Number(match[2]),
  };
}

function getDirectionBetween(left: CellCoord, right: CellCoord): GridDirection | null {
  const rowDelta = right.row - left.row;
  const colDelta = right.col - left.col;

  return (
    (Object.entries(DIRECTION_STEPS).find(
      ([, step]) => step.row === rowDelta && step.col === colDelta,
    )?.[0] as GridDirection | undefined) ?? null
  );
}

export function expandEntryLine(line: EntryLine): CellCoord[] {
  const step = DIRECTION_STEPS[line.direction];
  if (!step) {
    throw new Error(`Unsupported entry path direction: ${line.direction}`);
  }

  if (!Number.isInteger(line.length) || line.length < 1) {
    throw new Error("Entry path line length must be a positive integer.");
  }

  return Array.from({ length: line.length }, (_, index) => ({
    row: line.start.row + step.row * index,
    col: line.start.col + step.col * index,
  }));
}

export function expandEntryPath(path: EntryPath): CellCoord[] {
  const segments = path.kind === "line" ? [path.segment] : path.segments;
  const coords: CellCoord[] = [];

  segments.forEach((segment, segmentIndex) => {
    const segmentCoords = expandEntryLine(segment);
    if (segmentIndex === 0) {
      coords.push(...segmentCoords);
      return;
    }

    const previous = coords[coords.length - 1];
    const first = segmentCoords[0];
    if (!previous || !first || previous.row !== first.row || previous.col !== first.col) {
      throw new Error("Entry path segments must connect end-to-start.");
    }

    coords.push(...segmentCoords.slice(1));
  });

  const seen = new Set<string>();
  for (const coord of coords) {
    const key = coordKey(coord);
    if (seen.has(key)) {
      throw new Error("Entry path may not visit the same cell twice.");
    }
    seen.add(key);
  }

  return coords;
}

export function expandEntryPathToCellIds(path: EntryPath): string[] {
  return expandEntryPath(path).map(cellIdFromCoord);
}

export function validateEntryPath(path: EntryPath, cells: Cell[]): void {
  const occupied = new Set(cells.map((cell) => coordKey(cell)));
  const coords = expandEntryPath(path);

  if (coords.length < 2) {
    throw new Error("An extra entry must include at least two cells.");
  }

  for (const coord of coords) {
    if (!occupied.has(coordKey(coord))) {
      throw new Error(
        `Extra entry ${path.label ?? path.id} includes an unoccupied cell at row ${coord.row + 1}, column ${coord.col + 1}.`,
      );
    }
  }
}

export function inferEntryPathFromCellIds(
  id: string,
  cellIds: string[],
  label?: string,
): EntryPath {
  const coords = cellIds.map((cellId) => {
    const coord = coordFromCellId(cellId);
    if (!coord) {
      throw new Error(`Invalid cell id in entry path: ${cellId}`);
    }
    return coord;
  });

  if (coords.length < 2) {
    throw new Error("An extra entry must include at least two cells.");
  }

  const segments: EntryLine[] = [];
  let segmentStart = coords[0];
  let segmentDirection = getDirectionBetween(coords[0], coords[1]);
  if (!segmentDirection) {
    throw new Error("Extra entry cells must be contiguous.");
  }
  let segmentLength = 2;

  for (let i = 2; i < coords.length; i += 1) {
    const direction = getDirectionBetween(coords[i - 1], coords[i]);
    if (!direction) {
      throw new Error("Extra entry cells must be contiguous.");
    }

    if (direction === segmentDirection) {
      segmentLength += 1;
      continue;
    }

    segments.push({
      kind: "line",
      start: segmentStart,
      direction: segmentDirection,
      length: segmentLength,
    });

    segmentStart = coords[i - 1];
    segmentDirection = direction;
    segmentLength = 2;
  }

  segments.push({
    kind: "line",
    start: segmentStart,
    direction: segmentDirection,
    length: segmentLength,
  });

  if (segments.length === 1) {
    return {
      kind: "line",
      id,
      label,
      segment: segments[0],
    };
  }

  return {
    kind: "polyline",
    id,
    label,
    segments,
  };
}

export function describeEntryPath(path: EntryPath): string {
  const cellIds = expandEntryPathToCellIds(path);
  return cellIds.join(" → ");
}
